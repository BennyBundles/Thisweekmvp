#include "../Source/MelodyCore.h"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace equinox;
int main(){
 for(int st=0;st<6;st++) for(int sc=0;sc<5;sc++) for(int seed=1;seed<=12;seed++) {
    Settings s;s.style=(Style)st;s.scale=(Scale)sc;s.root=seed%12;
    s.seed=seed;s.bpm=defaultBpm(s.style);s.density=seed/12.;
    auto p=generate(s);auto q=generate(s);
    assert(!p.notes.empty());
    assert(p.notes.size()==q.notes.size());
    int counts[kTracks]{};
    for(size_t i=0;i<p.notes.size();++i){
        const auto& n=p.notes[i];assert(n.track>=0&&n.track<kTracks);
        assert(n.pitch>=21&&n.pitch<=108);assert(n.velocity>=1&&n.velocity<=127);
        assert(n.beat>=0&&n.beat<32.);assert(n.duration>0&&n.beat+n.duration<=32.00000001);
        assert(n.track==q.notes[i].track&&n.pitch==q.notes[i].pitch&&n.beat==q.notes[i].beat);
        counts[n.track]++;
    }
    int active=0;for(int count:counts)if(count)active++;
    assert(active>=3&&active<=13); // no sixteen-part wall of sound; unused MIDI stems are intentional
    assert(counts[0]>0);
    assert(p.chords.size()==8);
    auto pOther=p;
    pOther.settings.patches[7]=3;
    assert(pOther.settings.patches[7]!=p.settings.patches[7]);
    auto bytes=exportMidi(p); assert(bytes.size()>100&&bytes[0]=='M'&&bytes[1]=='T');
    for(int t=0;t<kTracks;++t){auto m=exportMidi(p,t);assert(m.size()>45);}
    if(st==0&&sc==0&&seed==1){
       auto wav=AudioEngine::renderWav(p,8000);assert(wav.size()>50000);
       assert(wav[0]=='R'&&wav[1]=='I'&&wav[8]=='W');
       size_t nonzero=0;for(size_t i=44;i<wav.size();++i) if(wav[i])++nonzero;
       assert(nonzero>25000);
       auto audioOther=AudioEngine::renderWav(pOther,8000);
       auto audioBase=AudioEngine::renderWav(p,8000);
       assert(audioBase.size()==audioOther.size());
       // v0.6 may legitimately leave the choir track silent; source patch remains stateful
    }
 }
 Settings silence;silence.vocalAmount=0.;silence.atmosphere=0.;
 auto dry=generate(silence);
 for(auto& n:dry.notes)assert(n.track!=7&&n.track!=8&&n.track!=9&&n.track!=10&&n.track!=14);
 std::cout<<"PASS: 360 randomized composition configurations; sparse layers, MIDI and WAV validated.\n";
}
