import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
from scipy.io import wavfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
  page=await browser.new_page(accept_downloads=True,viewport={'width':1280,'height':920})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content((ROOT/'web/EQUINOX_Live_Demo.html').read_text(),wait_until='domcontentloaded',timeout=60000)
  assert await page.evaluate('FACTORY_AUDIO.length')==320
  assert await page.evaluate('mutes.every(x=>x===false)'), 'Main melody track should not be pre-muted'
  for genre in range(6):
   await page.locator('#style').select_option(index=genre)
   signatures=[]
   for profile in (0,1,2):
    await page.locator('#substyle').select_option(str(profile))
    arr=await page.evaluate('pattern.map(n=>[n.t,n.n,Math.round(n.b*960)])')
    signatures.append(str(arr))
    assert 3 <= len(set(row[0] for row in arr)) <= 13
   assert len(set(signatures))==3,genre
  await page.locator('#style').select_option(index=3)
  await page.locator('#substyle').select_option('0')
  await page.locator('#play').click()
  await page.wait_for_function('factoryLoaded && playing',timeout=45000)
  print('play',await page.locator('#status').text_content(), 'factory',await page.evaluate('factorySamples.flat().filter(x=>x.buffer).length'),flush=True)
  await page.locator('#play').click()
  await page.screenshot(path=str(ROOT/'preview_1280.png'),full_page=True)
  async with page.expect_download(timeout=30000) as d:
   await page.locator('#export').click()
  file=await d.value;await file.save_as(str(ROOT/'tests/browser_export.mid'))
  assert (ROOT/'tests/browser_export.mid').read_bytes()[:4]==b'MThd'
  async with page.expect_download(timeout=120000) as d:
   await page.locator('#wav').click()
  file=await d.value;await file.save_as(str(ROOT/'tests/browser_export.wav'))
  sr,a=wavfile.read(str(ROOT/'tests/browser_export.wav'))
  print('wav sr',sr,'shape',a.shape,'peak',float(np.abs(a.astype(float)).max()/32768),'rms',float(np.sqrt(np.mean((a.astype(float)/32768)**2))),flush=True)
  assert a.shape[1]==2 and float(np.sqrt(np.mean((a.astype(float)/32768)**2)))>0.001
  print('browser errors',errors,flush=True);assert not errors
  await browser.close()
asyncio.run(run())
