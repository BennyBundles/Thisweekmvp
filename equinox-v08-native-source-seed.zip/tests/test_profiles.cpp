#include "../Source/MelodyCore.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <vector>
using namespace equinox;
static std::string sig(const Pattern& p){std::ostringstream o;for(auto n:p.notes)o<<n.track<<':'<<n.pitch<<'@'<<(int)std::round(n.beat*960)<<',';return o.str();}
int main(){
    int pass=0;
    for(int style=0;style<6;++style){
        double density[3]{};
        for(int k=0;k<18;++k){
           std::set<std::string> signatures;
           for(int profile=0;profile<3;profile++){
              Settings s;s.style=Style(style);s.substyle=profile;s.seed=uint32_t(4815+k*7919);
              s.root=(style+k)%12;s.scale=Scale(k%5);s.density=.64;s.vocalAmount=.55;
              auto p=generate(s); signatures.insert(sig(p));
              assert(p.notes.size()>=16 && p.notes.size()<=350);
              assert(p.notes.front().beat>=0);
              int bass=0, melody=0;
              for(const auto& n:p.notes){
                 if(n.track==0)bass++;
                 if(n.track!=0&&n.velocity>=55)melody++;
                 assert(n.track>=0&&n.track<16);
                 assert(n.beat>=0&&n.beat<32 && n.duration>=0.075-1e-6 && n.beat+n.duration<=32.000001);
                 assert(n.pitch>=21&&n.pitch<=108 && n.velocity>0&&n.velocity<=127);
              }
              assert(bass>=7 && melody>=10);
              density[profile]+=p.notes.size();pass++;
           }
           assert(signatures.size()==3);
        }
        std::cout<<styleNames[style]<<" avg notes / profile: "<<density[0]/18<<", "<<density[1]/18<<", "<<density[2]/18<<"\n";
    }
    std::cout<<"PASS: "<<pass<<" profile configurations, 108 sets with pairwise differences\n";
}
