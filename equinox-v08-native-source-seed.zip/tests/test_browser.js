'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../web/EQUINOX_Live_Demo.html','utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
class Elem{
 constructor(tag='div',id=''){this.tag=tag;this.id=id;this.style={};this.children=[];
  this.className='';this.textContent='';this.value='';this.selectedIndex=0;this.clientWidth=1000;
  this.classList={add(){},remove(){},toggle(){}};}
 add(el){this.children.push(el)}append(...els){this.children.push(...els)}appendChild(el){this.children.push(el)}
 remove(){this.removed=true}setAttribute(){}addEventListener(){}replaceChildren(...els){this.children=[...els]}
 querySelectorAll(sel){return sel==='.lane'?this.children.filter(e=>e.className==='lane'&&!e.removed):[]}
}
let els={};
for(let id of ['blueprint','root','substyle','style','scale','bpm','density','swing','emotion','vocals','atmosphere','bpmV','densityV','swingV','emotionV','vocalsV','atmosphereV','chords','lanes','head','status','seedText','generate','mutate','play','export','stems','wav','warmth','humanize','room','warmthV','humanizeV','roomV'])els[id]=new Elem('div',id);
els.style.selectedIndex=3;els.substyle.value='-1';els.scale.selectedIndex=0;els.root.value='9';
Object.assign(els.bpm,{value:'132'});Object.assign(els.density,{value:'65'});
Object.assign(els.warmth,{value:'42'});Object.assign(els.humanize,{value:'31'});Object.assign(els.room,{value:'18'});Object.assign(els.swing,{value:'12'});Object.assign(els.emotion,{value:'70'});Object.assign(els.vocals,{value:'75'});Object.assign(els.atmosphere,{value:'65'});
const document={getElementById:k=>els[k],createElement:tag=>new Elem(tag),body:new Elem('body')};
const window={addEventListener(){},URL:{createObjectURL(){return'x'}},innerWidth:1100};
const context=vm.createContext({document,window,Option:class{constructor(text,value){this.text=text;this.value=value}},Math,Array,Number,setTimeout,clearTimeout,requestAnimationFrame(){},cancelAnimationFrame(){},Blob,TextEncoder});
vm.runInContext(js,context);
let pass=0;
for(let style=0;style<6;style++)for(let sc=0;sc<5;sc++)for(let key=0;key<12;key++){
 els.style.selectedIndex=style;els.scale.selectedIndex=sc;els.root.value=key+'';
 vm.runInContext('seed+=7919;makePattern()',context);
 const pattern=vm.runInContext('window.EQUINOX_TEST.pattern()',context);
 const types=new Set(pattern.map(n=>n.t));
 assert(types.size>=3&&types.size<=13,`expected intentional rests: ${types.size}`);
 assert(types.has(0),`no bass on style ${style}`);
 assert(pattern.every(n=>n.b>=0&&n.b<32&&n.d>0&&n.b+n.d<=32.000001&&n.n>=21&&n.n<=108));
 let b=vm.runInContext('window.EQUINOX_TEST.midi()',context);
 if(style===0&&sc===0&&key===0){let z=vm.runInContext('window.EQUINOX_TEST.zipLayers()',context);assert.strictEqual(String.fromCharCode(...z.slice(0,4)),'PK\x03\x04');assert(z.length>3000);}
 assert.strictEqual(String.fromCharCode(...b.slice(0,4)),'MThd');
 assert.strictEqual(b[11],17,'1 tempo + 16 instrument MIDI tracks');
 assert(els.chords.children.length===8);
 pass++;
}
console.log('PASS:',pass,'browser generator configurations, sixteen-layer piano roll and MIDI headers');
