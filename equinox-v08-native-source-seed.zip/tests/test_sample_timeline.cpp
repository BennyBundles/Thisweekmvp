#include "SampleTimeline.h"
#include <cassert>
#include <vector>
#include <iostream>
#include <cmath>
using namespace equinox;
static std::vector<SampleSpan> spans(double beat,int frames,double note=0.,double duration=1.,double bpm=120.,double release=.1){
 std::vector<SampleSpan> out;
 forSampleSpans(beat,bpm,48000.,frames,note,duration,release,[&](SampleSpan s){out.push_back(s);});
 return out;
}
int main(){
 // Inside note, all frames active.
 auto s=spans(.5,512);assert(s.size()==1 && s[0].firstFrame==0 && s[0].endFrame==512);
 // Just before note, a short partial block should begin at the correct frame.
 s=spans(-.01,512);assert(s.size()==1 && s[0].firstFrame>=239 && s[0].firstFrame<=241);
 // Outside current note, absolutely no render work.
 assert(spans(6.,512).empty());
 // A note late in the loop must continue its release through beat 32.
 s=spans(32.005,1024,31.9,.12,120.,.1);assert(s.size()==1 && s[0].firstFrame==0);
 // Original note at 0 repeats exactly at start of next 8-bar cycle.
 s=spans(31.99,1024,0.,.5);assert(s.size()==1 && s[0].firstFrame>=239 && s[0].firstFrame<=241);
 // Note is not inadvertently repeated within a loop.
 assert(spans(15.,1024,0.,.5).empty());
 // Zero frame, invalid BPM, no out-of-bounds spans.
 assert(spans(0.,0).empty());
 int count=0;
 for(int i=-64;i<64000;++i){
   double beat=i*.0031;
   forSampleSpans(beat,145.,44100.,256,31.83,.16,.08,[&](SampleSpan z){
      assert(z.firstFrame>=0 && z.endFrame<=256 && z.firstFrame<z.endFrame);count++;
   });
 }
 assert(count>100);
 std::cout<<"PASS: sample timeline edge cases and 64k randomized transport positions, "<<count<<" active spans\n";
}
