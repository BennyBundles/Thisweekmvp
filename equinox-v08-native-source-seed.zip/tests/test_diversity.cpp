#include "../Source/MelodyCore.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>
using namespace equinox;
static std::string signature(const Pattern& p){
 std::ostringstream s;
 for(auto n:p.notes)s<<n.track<<':'<<n.pitch<<'@'<<(int)std::round(n.beat*16)<<',';
 return s.str();
}
int main(){
 std::array<std::set<std::string>,6> uniqueByStyle{};
 std::array<double,6> activeSum{},noteSum{};
 for(int i=0;i<6;i++)for(int seed=1;seed<=24;seed++){
  Settings s;s.style=Style(i);s.scale=Scale::NaturalMinor;s.root=9;
  s.seed=20261010+seed*9973;s.density=.56;s.vocalAmount=.42;s.atmosphere=.38;
  auto p=generate(s);auto sig=signature(p);
  uniqueByStyle[i].insert(sig);
  std::set<int>active;for(auto n:p.notes)active.insert(n.track);
  assert(active.size()>=3&&active.size()<=13);
  assert(p.notes.size()>=20&&p.notes.size()<=300);
  activeSum[i]+=active.size();noteSum[i]+=p.notes.size();
  for(int other=0;other<i;other++){
   s.style=Style(other);auto q=generate(s);
   assert(sig!=signature(q));
  }
 }
 for(int i=0;i<6;i++){
  assert(uniqueByStyle[i].size()>=22);
  std::cout<<styleNames[i]<<": unique="<<uniqueByStyle[i].size()<<"/24 avg_active="
    <<activeSum[i]/24<<" avg_notes="<<noteSum[i]/24<<"\n";
 }
 std::cout<<"PASS: 144 generation runs plus cross-genre signature comparisons\n";
}
