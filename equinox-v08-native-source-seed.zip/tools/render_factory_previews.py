import json, os, functools, subprocess
import numpy as np, soundfile as sf, mido
from scipy.signal import butter,sosfilt
ROOT=str(__import__('pathlib').Path(__file__).resolve().parents[1]); S=os.path.join(ROOT,'Samples')
MANIFEST=json.load(open(ROOT+'/sample_manifest.json'))
BANK={}
for x in MANIFEST:BANK.setdefault((x['track'],x['patch'],x['velocity_layer']),[]).append(x)
SR=22050
@functools.lru_cache(maxsize=180)
def sample(path):
 wave,sr=sf.read(os.path.join(S,path),dtype='float32');
 if wave.ndim>1:wave=wave.mean(axis=1)
 return wave,sr

def read_midi(path):
 mi=mido.MidiFile(path)
 assert mi.ticks_per_beat==960
 tempo=500000
 for msg in mi.tracks[0]:
  if msg.type=='set_tempo':tempo=msg.tempo;break
 bpm=round(60000000/tempo)
 tracks=[]
 for idx,tr in enumerate(mi.tracks[1:]):
  notes=[];opened={};tic=0
  for msg in tr:
   tic+=msg.time
   if msg.type=='note_on' and msg.velocity>0:opened.setdefault(msg.note,[]).append((tic,msg.velocity))
   elif msg.type in ('note_off','note_on') and msg.note in opened and opened[msg.note]:
    on,vel=opened[msg.note].pop(0);notes.append((msg.note,on/960.,max(.015,(tic-on)/960.),vel))
  tracks.append(notes)
 return bpm, tracks

def render_one(filename):
 bpm,tracks=read_midi(filename);dur=(32*60/bpm)+2.0;count=int(dur*SR)
 audio=np.zeros((count,2),np.float32)
 gains=[.39,.35,.33,.37,.27,.33,.31,.24,.17,.19,.21,.26,.31,.28,.17,.34]
 pans=[0,-.17,.16,.20,-.22,.25,0,-.20,.17,.25,-.25,.20,0,.16,-.3,.13]
 diag=[]
 for t,notes in enumerate(tracks):
  for note,beat,length,v in notes:
   patch=0;vel=0 if v<88 else 1
   bank=BANK.get((t,patch,vel),[])
   if not bank:continue
   obj=min(bank,key=lambda k:abs(k['root']-note))
   w,sr=sample(obj['filename']);rate=2**((note-obj['root'])/12)
   # Pitch by sample-rate conversion, truncate to note length and use a smooth gate/release
   destlen=min(int((length*60/bpm+.16)*SR),int(len(w)*SR/(sr*rate)))
   if destlen<8:continue
   indices=np.arange(destlen,dtype=np.float64)*(sr/SR)*rate
   shifted=np.interp(indices,np.arange(len(w)),w).astype(np.float32)
   attack=min(int(.012*SR),destlen//6);release=min(int(.1*SR),destlen//3)
   if attack>0:shifted[:attack]*=np.linspace(0,1,attack,dtype=np.float32)
   if release>0:shifted[-release:]*=np.linspace(1,0,release,dtype=np.float32)
   begin=int(beat*60/bpm*SR);end=min(begin+destlen,count)
   signal=shifted[:end-begin]*gains[t]*(.6+v/210.)
   pan=pans[t];audio[begin:end,0]+=signal*(1-pan)*.75;audio[begin:end,1]+=signal*(1+pan)*.75
  if notes:diag.append((t,len(notes)))
 # subtle air damping for an un-hyped reference; no invented premium recordings
 for ch in (0,1):
  b=butter(2,8800,fs=SR,btype='low',output='sos');audio[:,ch]=sosfilt(b,audio[:,ch])
 peak=float(np.max(np.abs(audio)))
 if peak>0:audio*=min(.91/peak,1.35)
 dst=filename.rsplit('.',1)[0]+'_SAMPLED.wav';sf.write(dst,audio,SR,subtype='PCM_16')
 mp3=dst.replace('.wav','.mp3')
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',dst,'-codec:a','libmp3lame','-q:a','3',mp3],check=True)
 os.unlink(dst)
 return bpm,diag,mp3

if __name__=='__main__':
 for n in ['trap','hiphop','drill','pain','southern','jazz_trap']:
  f=f'{ROOT}/examples/equinox_{n}.mid';bpm,notes,mp3=render_one(f)
  print(n,bpm,'active',len(notes),'notes',sum(count for t,count in notes),'mp3',os.stat(mp3).st_size,flush=True)
 for genre in ['pain','drill']:
  for profile in ['intimate','pocket','cinematic']:
   f=f'{ROOT}/examples/ProducerProfiles/{genre}_{profile}.mid';bpm,notes,mp3=render_one(f)
   print(genre,profile,bpm,'active',len(notes),'notes',sum(count for t,count in notes),'mp3',os.stat(mp3).st_size,flush=True)
