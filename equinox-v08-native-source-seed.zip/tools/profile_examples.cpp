#include "../Source/MelodyCore.h"
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace equinox;
int main(int argc,char**argv){
  std::string dir=(argc>1?argv[1]:"examples/ProducerProfiles");
  std::filesystem::create_directories(dir);
  constexpr const char* genres[]={"trap","hiphop","drill","pain","southern","jazz_trap"};
  constexpr const char* approaches[]={"intimate","pocket","cinematic"};
  for(int st=0;st<6;++st)for(int approach=0;approach<3;++approach){
    Settings s;s.style=Style(st);s.substyle=approach;s.bpm=defaultBpm(s.style);
    s.root=9;s.scale=st==5?Scale::Dorian:st==2?Scale::HarmonicMinor:Scale::NaturalMinor;
    s.seed=20261010+7919*st;s.density=.64;s.swing=st==1?.28:st==5?.22:.12;
    s.vocalAmount=.48;s.atmosphere=.39;
    const auto p=generate(s);const std::string file=dir+"/"+genres[st]+"_"+approaches[approach];
    if(!writeBinary(file+".mid",exportMidi(p)))return 1;
    std::ofstream text(file+".txt");text<<describe(p)<<"Substyle: "<<approaches[approach]<<"\n";
    std::cout<<file<<" "<<p.notes.size()<<" notes\n";
  }
}
