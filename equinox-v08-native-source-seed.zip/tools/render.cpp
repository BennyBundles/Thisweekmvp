#include "../Source/MelodyCore.h"
#include <filesystem>
#include <iostream>
#include <string>
using namespace equinox;
int main(int argc,char**argv){
    std::string dest=argc>1?argv[1]:"examples";
    std::filesystem::create_directories(dest);
    const Style styles[] = {Style::Trap,Style::HipHop,Style::Drill,Style::Pain,Style::Southern,Style::JazzTrap};
    const char* names[]={"trap","hiphop","drill","pain","southern","jazz_trap"};
    for(int i=0;i<6;++i){
        Settings s;s.style=styles[i];s.bpm=defaultBpm(s.style);s.seed=20261010+i*7919;
        s.root=(i*2+9)%12;
        s.scale=(i==5?Scale::Dorian:(i==2?Scale::HarmonicMinor:Scale::NaturalMinor));
        s.density=.62+(i%3)*.08;s.swing=(i==5?.29:.1);
        Pattern p=generate(s);
        const std::string root=dest+"/equinox_"+names[i];
        if(!writeBinary(root+".mid",exportMidi(p)) || !writeBinary(root+".wav",AudioEngine::renderWav(p,22050))){
            std::cerr << "Failed to write " << root << '\n';return 1;
        }
        for(int t=0;t<kTracks;++t) {
            if(!writeBinary(root+"_layer_"+std::to_string(t+1)+".mid",exportMidi(p,t)))return 1;
            // The pain preset gets isolated vocal/texture audio previews for FL Studio.
            if(i==3 && t>=7 && t<=11)
                if(!writeBinary(root+"_layer_"+std::to_string(t+1)+".wav",AudioEngine::renderWav(p,22050,t)))return 1;
        }
        std::cout << describe(p) << "\n";
    }
    return 0;
}
