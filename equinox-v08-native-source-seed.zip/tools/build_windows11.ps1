#Requires -Version 5.1
# EQUINOX v0.8 native build: capture diagnostics for precise iterative repairs.
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$logs = Join-Path $project 'windows-build-logs'
$null = New-Item -ItemType Directory -Force -Path $logs
$report = Join-Path $project 'WINDOWS_BUILD_REPORT.zip'
$success = $false
$problem = ''
$envLog = Join-Path $logs 'environment.txt'
$buildPath = Join-Path $project 'build-win'
function Run-Step([string] $Name, [string] $File, [string[]] $ArgList) {
    $log = Join-Path $logs "$Name.log"
    "COMMAND: $File $($ArgList -join ' ')" | Out-File -FilePath $log -Encoding utf8
    # Windows PowerShell 5.1 treats some native stderr text (e.g. Git progress)
    # as a terminating PowerShell error when ErrorActionPreference is Stop.
    # Capture stderr but make success depend on the native exit code.
    $oldPreference=$ErrorActionPreference
    $ErrorActionPreference='Continue'
    try { & $File @ArgList 2>&1 | Out-File -FilePath $log -Append -Encoding utf8 }
    finally { $ErrorActionPreference=$oldPreference }
    if ($LASTEXITCODE -ne 0) {
        throw "Step '$Name' failed (exit code $LASTEXITCODE). Review windows-build-logs\$Name.log."
    }
}
try {
    "EQUINOX v0.8 Windows build | $([DateTime]::Now.ToString('s'))" | Out-File $envLog -Encoding utf8
    "OS: $([Environment]::OSVersion.VersionString)" | Out-File $envLog -Append
    "Architecture: $env:PROCESSOR_ARCHITECTURE" | Out-File $envLog -Append
    "Project: $project" | Out-File $envLog -Append
    $cmake = Get-Command cmake.exe -ErrorAction SilentlyContinue
    $git = Get-Command git.exe -ErrorAction SilentlyContinue
    if (-not $cmake) {throw 'CMake not found. Install Visual Studio C++ workload with CMake support, or CMake from cmake.org.'}
    if (-not $git) {throw 'Git not found. Install Git for Windows (https://git-scm.com/download/win).'}
    "CMake: $($cmake.Source)" | Out-File $envLog -Append
    "Git: $($git.Source)" | Out-File $envLog -Append
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path $vswhere)) {throw 'Visual Studio Installer not found. Install Visual Studio Community with Desktop development with C++.'}
    $visual = (& $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationVersion).Trim()
    if (-not $visual) {throw 'Visual Studio C++ toolchain not installed. Enable Desktop development with C++ in Visual Studio Installer.'}
    $major = [int]($visual.Split('.')[0])
    $generator = switch ($major) { 17 {'Visual Studio 17 2022'} 18 {'Visual Studio 18 2026'} default {throw "Unsupported Visual Studio version: $visual"} }
    "Visual Studio: $visual | $generator" | Out-File $envLog -Append
    $jucePath = $env:JUCE_DIR
    if (-not $jucePath -or -not (Test-Path (Join-Path $jucePath 'CMakeLists.txt'))) {
        $jucePath = Join-Path $project '_deps\JUCE'
        if (-not (Test-Path (Join-Path $jucePath 'CMakeLists.txt'))) {
            $null = New-Item -ItemType Directory -Force -Path (Join-Path $project '_deps')
            Write-Host 'Cloning the official JUCE 9.0.2 sources...'
            Run-Step 'get-juce' $git.Source @('clone','--depth','1','--branch','9.0.2','https://github.com/juce-framework/JUCE.git',$jucePath)
        }
    }
    "JUCE: $jucePath" | Out-File $envLog -Append
    $params = @('-S',$project,'-B',$buildPath,'-G',$generator,'-A','x64',"-DJUCE_DIR=$($jucePath -replace '\\','/')",'-DEQUINOX_BUILD_PLUGIN=ON')
    Write-Host 'Configuring native 64-bit VST3...'
    Run-Step 'configure' $cmake.Source $params
    Write-Host 'Compiling VST3 and Standalone...'
    Run-Step 'build-vst3' $cmake.Source @('--build',$buildPath,'--config','Release','--target','EQUINOXMelodyForge_VST3','--parallel','3')
    Run-Step 'build-standalone' $cmake.Source @('--build',$buildPath,'--config','Release','--target','EQUINOXMelodyForge_Standalone','--parallel','3')
    Write-Host 'Running standalone core regression checks...'
    Run-Step 'core-tests' $cmake.Source @('--build',$buildPath,'--config','Release','--target','equinox_test','equinox_diversity_test','equinox_profiles_test','equinox_sampler_timeline_test','--parallel','3')
    $ctest = Get-Command ctest.exe -ErrorAction Stop
    Run-Step 'ctest' $ctest.Source @('--test-dir',$buildPath,'-C','Release','--output-on-failure')
    $bundle = Get-ChildItem -LiteralPath $buildPath -Recurse -Directory -Filter '*.vst3' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $bundle) {throw 'Build reported success, but no VST3 bundle was found.'}
    "VST3: $($bundle.FullName)" | Out-File $envLog -Append
    $bundle.FullName | Set-Content (Join-Path $project 'WINDOWS_BUILT_VST3_LOCATION.txt')
    $success = $true
    Write-Host "SUCCESS: VST3 built at $($bundle.FullName)" -ForegroundColor Green
} catch {
    $problem = $_.Exception.Message
    Write-Host "BUILD ERROR: $problem" -ForegroundColor Red
} finally {
    "Success: $success`nProblem: $problem" | Set-Content (Join-Path $logs 'result.txt')
    if (Test-Path $report) { Remove-Item -LiteralPath $report -Force }
    Compress-Archive -Path (Join-Path $logs '*') -DestinationPath $report -CompressionLevel Optimal -Force
    Write-Host "Diagnostics: $report"
}
if (-not $success) {exit 1}
