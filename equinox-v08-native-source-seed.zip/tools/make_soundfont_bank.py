import ctypes as C, ctypes.util, numpy as np, soundfile as sf, os, shutil, subprocess, json
from pathlib import Path
out=Path(__file__).resolve().parents[1]
out.mkdir(exist_ok=True)
samples=out/'Samples'; samples.mkdir(exist_ok=True)
lib=C.CDLL(ctypes.util.find_library('fluidsynth'))
def f(name,rest,args):
 fn=getattr(lib,name);fn.restype=rest;fn.argtypes=args;return fn
ptr=C.c_void_p; I=C.c_int
settings=f('new_fluid_settings',ptr,[])()
f('fluid_settings_setnum',I,[ptr,C.c_char_p,C.c_double])(settings,b'synth.sample-rate',32000.)
f('fluid_settings_setint',I,[ptr,C.c_char_p,I])(settings,b'synth.reverb.active',0)
f('fluid_settings_setint',I,[ptr,C.c_char_p,I])(settings,b'synth.chorus.active',0)
synth=f('new_fluid_synth',ptr,[ptr])(settings)
sfid=f('fluid_synth_sfload',I,[ptr,C.c_char_p,I])(synth,str(out/'third_party'/'TimGM6mb.sf2').encode(),1)
print('soundfont id',sfid)
program=f('fluid_synth_program_change',I,[ptr,I,I]);noteon=f('fluid_synth_noteon',I,[ptr,I,I,I]);noteoff=f('fluid_synth_noteoff',I,[ptr,I,I]);allsounds=f('fluid_synth_all_sounds_off',I,[ptr,I]);write=f('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I])
# program numbers are zero-based General MIDI indices
presets=[
('SUB_808',38,[36,43,48],'Synth bass sampled patch (not acoustic)'),
('LOW_PIANO',0,[43,50,57],'Acoustic grand piano sampled patch'),
('UPPER_KEYS',0,[60,67,74],'Acoustic grand piano sampled patch'),
('GUITAR',24,[52,59,66],'Nylon acoustic guitar sampled patch'),
('STRINGS',48,[55,62,69],'Ensemble strings sampled patch'),
('BELLS',9,[72,79,86],'Glockenspiel sampled patch'),
('HOOK_LEAD',68,[64,71,78],'Oboe sampled patch (acoustic lead)'),
('CHOIR',52,[52,59,66],'General MIDI choir-Aahs sample patch; vocalist provenance unverified'),
('CHANTS',53,[48,55,62],'General MIDI voice-Oohs sample patch; not actual chants'),
('VOCAL_CHOPS',52,[64,71,78],'Choir-Aahs chopped sampled patch; not actual vocal takes'),
('PADS',89,[52,59,66],'Warm sampled pad (electronic timbre)'),
('ARPEGGIATOR',46,[64,71,78],'Concert harp sampled patch'),
('SYNTH_BASS',38,[36,43,50],'Synth bass sampled patch'),
('POLY_SYNTH',4,[55,62,69],'Electric piano patch (sample-based)'),
('ORGANIC_TEXTURE',73,[60,67,74],'Flute sampled patch; breath and room may be present'),
('PLUCK',12,[67,74,81],'Marimba sampled patch')]
manifest=[]
for track,(name,pr,roots,desc) in enumerate(presets):
 for root in roots:
  allsounds(synth,0);program(synth,0,pr);noteon(synth,0,root,112)
  count=int(2.35*32000);left=np.zeros(count,dtype=np.float32);right=np.zeros(count,dtype=np.float32)
  # render 2.35s held, 0.65 release
  hold=int(1.7*32000)
  def render(arrl,arrr,off,n):
   a=np.zeros(n,dtype=np.float32);b=np.zeros(n,dtype=np.float32)
   write(synth,n,a.ctypes.data,0,1,b.ctypes.data,0,1)
   arrl[off:off+n]=a;arrr[off:off+n]=b
  render(left,right,0,hold);noteoff(synth,0,root);render(left,right,hold,count-hold)
  data=np.stack([left,right],1)
  # remove misleading empty patch, basic fade-out for self-contained notes
  rms=float(np.sqrt(np.mean(data**2)))
  peak=float(np.max(np.abs(data)))
  if peak<.002: print('warning silent!',name,pr,root,peak)
  if peak>.005:data=data/peak*.82
  f=np.linspace(1.,0.,min(1800,count),dtype=np.float32)
  data[-len(f):]*=f[:,None]
  fname=f'{track:02d}_{name}_{root}.wav'
  sf.write(samples/fname,data,32000,subtype='PCM_16')
  # compress transport/embedded format; browsers decode OGG Vorbis via Web Audio
  oggname=fname.replace('.wav','.ogg')
  subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(samples/fname),'-c:a','libvorbis','-qscale:a','3',str(samples/oggname)],check=True)
  manifest.append({'track':track,'name':name,'root':root,'filename':fname,'web':oggname,'origin':'TimGM6mb.sf2','program':pr,'description':desc,'peak':round(peak,5),'rms':round(rms,5)})
  print(track, name, root, 'rms', round(rms,4), 'size',os.stat(samples/oggname).st_size)
(out/'sample_manifest.json').write_text(json.dumps(manifest,indent=2))
shutil.copy2('/usr/share/sounds/sf2/TimGM6mb.sf2',out/'third_party'/'TimGM6mb.sf2') if (out/'third_party').exists() else None
