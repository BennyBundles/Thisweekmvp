#pragma once
#include <algorithm>
#include <cmath>

// Platform-independent 8-bar note scheduler. No JUCE dependency, memory
// allocation, or time-consuming modulo performed for every audio sample.
namespace equinox {
constexpr double kSamplerLoopBeats=32.;
struct SampleSpan {
    int firstFrame;       // inclusive, within the current audio block
    int endFrame;         // exclusive
    double startBeat;     // absolute (unwrapped) beat on which this note began
};

template<class Callback>
void forSampleSpans(double blockBeat, double bpm, double sampleRate,
                    int blockFrames, double noteBeat, double durationBeats,
                    double releaseSeconds, Callback emit) {
    if (!(bpm>0) || !(sampleRate>0) || blockFrames<=0 || durationBeats<=0) return;
    const double beatsPerFrame=bpm/(60.*sampleRate);
    const double blockEnd=blockBeat + blockFrames*beatsPerFrame;
    const double releaseBeats=std::max(0.,releaseSeconds)*bpm/60.;
    const long firstCycle=(long)std::floor((blockBeat-noteBeat-durationBeats-releaseBeats)/kSamplerLoopBeats);
    const long lastCycle=(long)std::ceil((blockEnd-noteBeat)/kSamplerLoopBeats);
    for(long cycle=firstCycle;cycle<=lastCycle;++cycle) {
        const double started=noteBeat+cycle*kSamplerLoopBeats;
        const int first=std::clamp((int)std::ceil((started-blockBeat)/beatsPerFrame-1e-9),0,blockFrames);
        const int end=std::clamp((int)std::ceil((started+durationBeats+releaseBeats-blockBeat)/beatsPerFrame-1e-9),0,blockFrames);
        if(end>first) emit(SampleSpan{first,end,started});
    }
}
}
