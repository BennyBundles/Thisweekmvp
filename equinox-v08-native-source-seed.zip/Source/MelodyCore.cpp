#include "MelodyCore.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <random>
#include <sstream>

namespace equinox {
const std::array<const char*, kTracks> trackNames = {
    "SUB / 808", "LOW PIANO", "UPPER KEYS", "GUITAR", "LUSH STRINGS", "BELLS", "HOOK LEAD",
    "CHOIR", "CHANTS", "VOCAL CHOPS", "PADS", "ARPEGGIATOR", "SYNTH BASS", "POLY SYNTH", "ORGANIC TEXTURE", "PLUCK"};
const std::array<std::array<const char*,4>,kTracks> patchNames = {{
    {{"Round 808", "Punch 808", "Modeled Warm", "Modeled Bright"}},
    {{"Warm Grand", "Bright Grand", "Modeled Warm", "Modeled Bright"}},
    {{"Grand Piano", "Electric Piano", "Modeled Warm", "Modeled Bright"}},
    {{"Nylon Guitar", "Steel Guitar", "Modeled Warm", "Modeled Bright"}},
    {{"String Ensemble", "Solo Violin", "Modeled Warm", "Modeled Bright"}},
    {{"Glockenspiel", "Music Box", "Modeled Warm", "Modeled Bright"}},
    {{"Oboe", "Alto Sax", "Modeled Warm", "Modeled Bright"}},
    {{"Choir Aahs (GM)", "Voice Oohs (GM)", "Modeled Warm", "Modeled Bright"}},
    {{"Voice Oohs (GM)", "Choir Aahs (GM)", "Modeled Warm", "Modeled Bright"}},
    {{"Ah Chop (GM)", "Ooh Chop (GM)", "Modeled Warm", "Modeled Bright"}},
    {{"Warm Pad (GM)", "Air Pad (GM)", "Modeled Warm", "Modeled Bright"}},
    {{"Concert Harp", "Vibraphone", "Modeled Warm", "Modeled Bright"}},
    {{"Round Synth Bass", "Resonant Bass", "Modeled Warm", "Modeled Bright"}},
    {{"Electric Piano", "Honky-Tonk", "Modeled Warm", "Modeled Bright"}},
    {{"Flute", "Pan Flute", "Modeled Warm", "Modeled Bright"}},
    {{"Marimba", "Kalimba", "Modeled Warm", "Modeled Bright"}},
}};
const std::array<const char*,6> styleNames = {"Trap", "Hip-Hop", "Drill", "Pain", "Southern", "Jazz Trap"};
const std::array<const char*,5> scaleNames = {"Natural Minor", "Harmonic Minor", "Dorian", "Phrygian", "Major"};
const std::array<const char*,12> rootNames = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
static constexpr double pi = 3.14159265358979323846;
int defaultBpm(Style style) { switch (style) {
    case Style::HipHop: return 94; case Style::Drill: return 142; case Style::Pain: return 132;
    case Style::Southern: return 140; case Style::JazzTrap: return 116;
    default: return 148; }}
static const std::array<std::array<int,7>,5> scales = {{
    {{0,2,3,5,7,8,10}}, {{0,2,3,5,7,8,11}}, {{0,2,3,5,7,9,10}},
    {{0,1,3,5,7,8,10}}, {{0,2,4,5,7,9,11}} }};
static int pos(int a, int m) { return ((a % m) + m) % m; }
static int degree(const Settings& s, int d, int octaveBase) {
    const int octave = (d >= 0 ? d/7 : (d-6)/7);
    return std::clamp(octaveBase + pos(s.root,12) + scales[(int)s.scale][pos(d,7)] + octave*12, 20, 108);
}
static double clampd(double v, double a, double b) { return std::max(a,std::min(b,v)); }
static void add(Pattern& p, int track, int pitch, double beat, double len, int vel) {
    if (beat < 0 || beat >= kLoopBeats || len <= 0) return;
    p.notes.push_back({track,std::clamp(pitch,21,108),beat,
                       std::min(len,kLoopBeats-beat),std::clamp(vel,1,127)});
}
static std::string chordSuffix(const Settings& s, int d) {
    const int root=degree(s,d,48), third=degree(s,d+2,48)-root;
    const int fifth=degree(s,d+4,48)-root, seventh=degree(s,d+6,48)-root;
    const bool halfDim=(third==3 && fifth==6);
    if(halfDim)return seventh==10 ? "m7b5" : "dim7";
    if(third==3)return seventh==11?"m(maj7)":"m7";
    if(third==4)return seventh==11?"maj7":"7";
    return "7";
}
// EQUINOX v0.6 genre-aware composition. Independent original algorithms derived
// from general arranging/music-theory practices, not any producer transcription.
Pattern generate(const Settings& settingsRaw) {
    Pattern p;p.settings=settingsRaw;auto& s=p.settings;
    s.bpm=std::clamp(s.bpm,65,195);s.root=pos(s.root,12);
    s.density=clampd(s.density,.05,1);s.swing=clampd(s.swing,0,.45);
    s.emotion=clampd(s.emotion,0,1);s.vocalAmount=clampd(s.vocalAmount,0,1);
    s.atmosphere=clampd(s.atmosphere,0,1);
    for(auto& patch:s.patches)patch=std::clamp(patch,0,3);
    std::mt19937 rng(s.seed);
    auto chance=[&](double prob){return std::generate_canonical<double,24>(rng)<prob;};
    auto range=[&](int a,int b){std::uniform_int_distribution<int>d(a,b);return d(rng);};
    auto choose=[&](size_t count){return (size_t)range(0,(int)count-1);};
    const int st=(int)s.style;
    const bool trap=st==0,hip=st==1,drill=st==2,pain=st==3,south=st==4,jazz=st==5;
    const std::array<std::array<std::array<int,4>,4>,6> palettes{{
      {{{{0,5,3,6}},{{0,6,5,6}},{{0,4,5,3}},{{0,3,6,5}}}},
      {{{{0,3,5,4}},{{0,5,3,4}},{{0,2,5,3}},{{0,4,3,5}}}},
      {{{{0,6,5,6}},{{0,1,6,5}},{{0,4,6,5}},{{0,6,1,6}}}},
      {{{{0,5,3,6}},{{0,3,6,4}},{{0,2,5,6}},{{0,6,3,5}}}},
      {{{{0,3,4,0}},{{0,5,3,4}},{{0,3,6,4}},{{0,4,3,0}}}},
      {{{{1,4,0,5}},{{0,3,5,4}},{{0,5,1,4}},{{2,5,1,4}}}}
    }};
    auto pal=palettes[st][choose(4)];std::array<int,4> prog{};
    int turn=range(0,3);for(int i=0;i<4;i++)prog[i]=pal[(i+turn)%4];
    bool slow=(pain||drill)&&chance(.68);
    std::array<int,8> roots{};for(int b=0;b<8;++b)roots[b]=prog[(slow?b/2:b)%4];
    const std::array<std::array<int,3>,6> leaders{{{{5,15,3}},{{2,3,15}},{{5,15,3}},{{3,2,3}},{{3,2,3}},{{6,2,3}}}};
    const std::array<std::array<int,2>,6> beds{{{{1,4}},{{1,13}},{{4,1}},{{1,4}},{{1,13}},{{1,13}}}};
    const std::array<std::array<int,2>,6> counters{{{{2,9}},{{15,9}},{{15,2}},{{7,15}},{{15,8}},{{15,11}}}};
    int lead=leaders[st][choose(3)],bed=beds[st][choose(2)],counter=counters[st][choose(2)];
    bool choir=s.vocalAmount>.12&&(pain||south)&&chance(.64);
    bool pad=s.atmosphere>.22&&chance(jazz?.22:.45);
    bool arp=!pain&&!hip&&chance(trap?.34:drill?.20:jazz?.48:.14);
    bool chants=s.vocalAmount>.22&&chance(drill?.22:south?.40:.12);
    bool strings=(pain||drill||trap)&&chance(pain?.48:.32);
    bool synthBass=(trap||drill)&&chance(.18);
    auto swung=[&](double beat){double e=beat*2;return std::min(31.995,beat+(std::abs(e-std::round(e))<1e-6 && ((int)std::round(e))%2 ? s.swing*.22:0));};
    auto vel=[&](int center,int half){return range(std::max(20,center-half),std::min(124,center+half));};
    auto notes=[&](int deg){std::vector<int> v={degree(s,deg,60),degree(s,deg+2,60),degree(s,deg+4,60)};
       if(jazz||hip||south)v.push_back(degree(s,deg+6,60));
       if(jazz)v.push_back(degree(s,deg+8,60));return v;};
    std::vector<int> prev;
    std::array<std::vector<int>,8> voices;
    for(int b=0;b<8;b++){
      auto base=notes(roots[b]);double best=1e9;
      for(int shift=-1;shift<=1;shift++)for(int invert=0;invert<3;invert++){
        auto v=base;for(auto& n:v)n+=shift*12;
        for(int i=0;i<invert;i++)v[i]+=12;
        std::sort(v.begin(),v.end());
        if(v.front()<48||v.back()>88)continue;
        double cost=0.;if(prev.empty()){
           double mean=0;for(int n:v)mean+=n;mean/=v.size();cost=std::abs(mean-66);
        } else for(int n:v){int d=100;for(int old:prev)d=std::min(d,std::abs(n-old));cost+=d;}
        cost+=std::abs(v.back()-v.front()-22)*.15;
        if(cost<best){best=cost;voices[b]=v;}
      }
      if(voices[b].empty()) voices[b]=base;
      prev=voices[b];
    }
    const std::array<std::array<int,6>,5> shapes{{{{0,1,2,1,0,-1}},{{0,-1,-2,0,1,0}},{{0,2,1,-1,0,1}},{{0,0,2,3,1,-1}},{{0,-2,-1,1,0,-1}}}};
    const auto shape=shapes[choose(shapes.size())];
    const std::array<std::vector<std::vector<double>>,6> grids{{
       {{{0,.75,1.5,2.75,3.5},{0,.5,1.75,2.5,3.25}}},
       {{{.25,1,1.75,2.75},{0,1.25,2.25,3.25}}},
       {{{.5,1.25,2.75,3.5},{0,.75,1.75,3.25},{.25,1.5,2.25,3.75}}},
       {{{0,1.5,2.75},{.5,2,3.25},{0,1.75,3.5}}},
       {{{0,.75,1.5,2.5,3.5},{.25,1,2,2.75,3.5}}},
       {{{.25,1.25,2.25,3.5},{0,.75,2,3},{.5,1.5,2.75,3.25}}}
    }};
    struct Slot{double beat;int deg;double dur;};
    std::array<std::vector<Slot>,4> phrases;
    std::vector<double> initial;
    for(int unit=0;unit<4;unit++){
      const int count=pain?3:drill?4:hip?4:5;
      auto a=grids[st][choose(grids[st].size())];
      if((unit==1||unit==3)&&chance(.7)&&!initial.empty())a=initial;
      if(unit==0)initial=a;
      for(int half=0;half<2;half++){
        const auto& grid=half==0?a:grids[st][choose(grids[st].size())];
        for(size_t j=0;j<grid.size() && (int)j<count;j++){
          if(half==1&&j==grid.size()-1&&chance(.45))continue;
          double t=grid[j];if(half==1&&j==0&&chance(.35))t+=.25;
          int contour=shape[(j+half*2)%6];
          if(unit==1&&j==grid.size()-1)contour--;
          if(unit==2&&j==grid.size()/2)contour+=2;
          if(unit==3&&j==grid.size()-1)contour=0;
          double dur=pain?(j==0?1.12:.58):hip?.55:drill?.28:jazz?.44:.43;
          if(j==grid.size()-1)dur*=1.5;
          phrases[unit].push_back({half*4+t,contour,dur});
        }
      }
    }
    for(int bar=0;bar<8;bar++){
      double start=bar*4.;int root=roots[bar],low=degree(s,root,36),rootPitch=degree(s,root,48);
      const auto& harm=voices[bar];
      p.chords[bar]=std::string(rootNames[pos(rootPitch,12)])+chordSuffix(s,root)+(jazz?" add9":"");
      // A single harmonic bed with deliberately controlled instrumentation.
      if(bed==1||bed==13){
        auto chordHits=jazz?std::vector<double>{0,1.75,3.25}:hip?std::vector<double>{0,2.5}:south?std::vector<double>{0,1.5,3}:pain?std::vector<double>{0}:drill?std::vector<double>{0,2.75}:std::vector<double>{0,2};
        for(double t:chordHits){if(t>0&&!chance(.42+.3*s.density))continue;
          double len=pain?3.3:jazz?.8:south?.86:1.35;
          int n=std::min((int)harm.size(),jazz?5:(hip||south?4:3));
          for(int i=0;i<n;i++)add(p,bed,harm[i],start+t+.05*i,std::min(len,3.9-t),vel(i==0?68:60,8));
        }
      }else if(bar==0||root!=roots[bar-1]){
        for(int i=0;i<std::min(3,(int)harm.size());++i)add(p,bed,harm[i],start,std::min(slow?7.4:3.7,32-start),vel(44-i*3,5));
      }
      std::vector<double> bass =drill?std::vector<double>{0,1.75,2.75}:south?std::vector<double>{0,1.5,2.75,3.5}:hip?std::vector<double>{0,2.5}:jazz?std::vector<double>{0,1.5,3}:trap?std::vector<double>{0,1.75,3.25}:std::vector<double>{0,2.5};
      for(int j=0;j<(int)bass.size();++j){if(j&&!chance(.36+s.density*.5))continue;
        int n=low;if(j>0&&chance(south?.36:.16))n=degree(s,root+(j%2?4:2),36);
        if(drill&&j==(int)bass.size()-1&&chance(.45))n+=12;
        add(p,0,n,swung(start+bass[j]),j==0?(pain?2.2:1.3):.52,vel(87,8));
      }
      // Lead motifs repeat and develop across four two-bar phrases.
      int unit=bar/2;
      for(size_t j=0;j<phrases[unit].size();++j){const auto& e=phrases[unit][j];
        if((int)(e.beat/4)!=bar%2)continue;
        int deg=root+e.deg;
        int octave=(lead==3||lead==2)?60:72;
        int note=degree(s,deg,octave);
        if(j==0&&unit==3&&chance(.35))note+=12;
        add(p,lead,note,swung(unit*8+e.beat),e.dur,vel(pain?81:76,12));
      }
      if(bar%2==1 && chance(.44+s.density*.15) && counter!=lead){
        auto offs=pain?std::vector<double>{2.75,3.5}:jazz?std::vector<double>{2.25,3.25}:std::vector<double>{2.5,3.25};
        for(int j=0;j<(int)offs.size();j++)add(p,counter,degree(s,root+(j==0?4:2),counter==15?72:60),swung(start+offs[j]),pain?.42:.27,vel(51,10));
      }
      if(choir&&bar%2==0&&s.vocalAmount>.25)for(int i=0;i<std::min(3,(int)harm.size());++i)
         add(p,7,harm[i],start+.12,std::min(slow?7.35:4.,32-start-.12),vel(40,6));
      if(pad&&bar%2==0&&s.atmosphere>.35&&bed!=10)for(int i=0;i<std::min(3,(int)harm.size());++i)
         add(p,10,harm[i],start+.05,std::min(slow?7.2:3.85,32-start-.05),vel(33,4));
      if(strings&&bar%2==0&&bed!=4)for(int i=0;i<std::min(2,(int)harm.size());++i)
         add(p,4,harm[i],start+.2,std::min(7.3,32-start-.2),vel(38,5));
      if(arp&&bar%2==1){const auto slots=drill?std::vector<double>{0,.5,1,1.75,2.75}:jazz?std::vector<double>{.25,1.25,2.25,3.5}:std::vector<double>{.5,1.5,2.5,3.25};
          for(int j=0;j<(int)slots.size();++j)add(p,11,harm[j%harm.size()]+12,start+slots[j],.24,vel(41,6));}
      // Chromatic approaches for jazz and blue-note guitar inflections for Southern soul.
      if(jazz&&bar%2==1&&chance(.68)){
        int target=degree(s,roots[(bar+1)%8]+2,72);
        add(p,lead,target-1,start+3.5,.15,vel(47,5));
        add(p,lead,target,start+3.75,.22,vel(60,8));
      }
      if(south&&lead==3&&bar%2==1&&chance(.7)){
        int fifth=degree(s,root+4,60);
        add(p,3,fifth-1,start+3.25,.15,vel(52,7));
        add(p,3,fifth,start+3.5,.32,vel(65,8));
      }
      if(chants&&bar%2==1&&chance(s.vocalAmount*.7))add(p,8,degree(s,root,48),start+3.5,.19,vel(52,8));
      if(synthBass&&bar%2==1)add(p,12,low+12,start+3.25,.5,vel(54,7));
      if(s.atmosphere>.42&&bar==0&&chance(.35))add(p,14,degree(s,root,60),.25,3.2,35);
      if(s.vocalAmount>.65&&!choir&&bar==6&&chance(.3))add(p,9,degree(s,root+4,72),start+2.5,.28,55);
    }

    // v0.7 PRODUCER PERFORMANCE ENGINE: a deterministic second-stage arranger.
    // Profiles alter articulation, rests, instrumentation and human phrasing rather than
    // just switching the patch on an otherwise identical piano roll.
    const uint32_t mixedSeed=s.seed^(s.seed>>13)^(s.seed>>21);
    const int profile=s.substyle>=0?std::clamp(s.substyle,0,2):(int)(mixedSeed%3);
    auto hashUnit=[&](const Note& n,int salt){
        uint32_t x=(uint32_t)n.pitch*0x9e3779b9u ^ (uint32_t)n.track*0x85ebca6bu ^
             (uint32_t)std::llround(n.beat*960)*0xc2b2ae35u ^ mixedSeed ^ (uint32_t)salt*0x27d4eb2du;
        x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;
        return (double)x/4294967295.0;
    };
    std::vector<Note> expressive;expressive.reserve(p.notes.size()+12);
    for(auto n:p.notes){
        int bar=(int)std::floor(n.beat/4);
        const double beatInBar=n.beat-4*bar;
        const double h=hashUnit(n,13);
        const bool isLead=n.track==lead,isBed=n.track==bed,isBass=n.track==0;
        // Arrangement: a related second half, with conscious dropouts / fills.
        // Protect the bass on beat one and preserve the recurring hook.
        if(profile==0){ // INTIMATE: more silence and emphasized lead
            if(n.track==counter && bar<4 && h<.78)continue;
            if(n.track==11 || n.track==12 || n.track==9)continue;
            if(isLead && beatInBar>2.5 && h<.28)continue;
            if(n.track==7 && (bar==2||bar==3))continue;
        } else if(profile==1){ // POCKET: rhythmic/microtiming articulation
            if(n.track==10 && bar>=4 && bar<=5)continue;
            if(n.track==4 && bar==3)continue;
        } else { // CINEMATIC: longer phrasing with contrast and swell
            if(n.track==11 && (bar==0||bar==1||bar==4))continue;
            if(n.track==counter && bar<2 && h<.7)continue;
            if(n.track==8 && bar<6)continue;
        }
        // Clear harmonic part roles. Avoid machine-gunning a pad or string.
        if((n.track==4||n.track==7||n.track==10) && n.duration<.5) n.duration=.6;
        if(isLead){
            const int minPitch=(lead==3||lead==2)?54:66;
            const int maxPitch=(lead==3||lead==2)?81:89;
            while(n.pitch>maxPitch)n.pitch-=12;
            while(n.pitch<minPitch)n.pitch+=12;
            double maxShift=hip?.065:pain?.023:drill?.025:jazz?.047:south?.045:.018;
            n.beat+= (h-.5)*2*maxShift;
            if(profile==0) n.duration*=pain?1.23:1.08;
            if(profile==1) n.duration*=drill?.72:south?.83:.88;
            if(profile==2) n.duration*=pain?1.33:1.1;
            // Natural hierarchy: downbeat, answer and final pickup are not equally loud.
            n.velocity+=(beatInBar<.13?9:beatInBar>=3.0?-6:2);
            if(bar>=6&&profile==2)n.velocity+=6;
        } else if(isBed){
            // Piano and guitar chords roll from low to high notes; grouped attacks don't
            // share a mathematically exact timestamp anymore.
            const bool organic=n.track==1||n.track==3||n.track==13;
            if(organic)n.beat+=.006*(n.pitch%9)+ (hashUnit(n,9)-.5)*.012;
            if(profile==1&&organic)n.duration*=.78;
            if(profile==2&&organic)n.duration*=1.08;
        } else if(isBass){
            if(beatInBar>.2 && profile==0&&h<.46)continue;
            n.velocity+=(beatInBar<.25?8:-4);
            if(profile==2&&beatInBar<.13)n.duration*=1.22;
        } else {
            if(n.track==15||n.track==11||n.track==9)n.beat+=(hashUnit(n,31)-.5)*.035;
            n.velocity+=(int)std::round((h-.5)*9);
        }
        // Beat positions are carefully bounded, preserving MIDI 8-bar legality.
        n.beat=std::clamp(n.beat,0.,31.999);
        n.velocity=std::clamp(n.velocity,25,122);
        n.duration=std::clamp(n.duration,.075,32.-n.beat);
        expressive.push_back(n);
    }
    p.notes.swap(expressive);
    // Cadence: resolve the final melodic gesture to the final chord root or third.
    // One clear landing prevents the loop from sounding like unrelated random notes.
    Note* lastLead=nullptr;
    for(auto& n:p.notes)if(n.track==lead && n.beat>=27.0){
       if(!lastLead||n.beat>lastLead->beat)lastLead=&n;
    }
    if(lastLead){
        int rootNote=degree(s,roots[7]+(profile==1?2:0),60);
        while(rootNote+12<=lastLead->pitch+3)rootNote+=12;
        while(rootNote>lastLead->pitch+6)rootNote-=12;
        lastLead->pitch=std::clamp(rootNote,45,90);
        lastLead->duration=std::clamp((31.87-lastLead->beat)*.86,.12,32.-lastLead->beat);
        lastLead->velocity=std::clamp(lastLead->velocity+7,1,127);
    }

    std::stable_sort(p.notes.begin(),p.notes.end(),[](const Note&a,const Note&b){
      return a.beat!=b.beat?a.beat<b.beat:a.track!=b.track?a.track<b.track:a.pitch<b.pitch;});
    p.notes.erase(std::unique(p.notes.begin(),p.notes.end(),[](const Note&a,const Note&b){return a.track==b.track&&a.pitch==b.pitch&&std::abs(a.beat-b.beat)<1e-6;}),p.notes.end());
    return p;
}

std::string describe(const Pattern& p) {
    std::ostringstream out;
    out << "EQUINOX MELODY FORGE | " << styleNames[(int)p.settings.style] << " | "
        << rootNames[p.settings.root] << " " << scaleNames[(int)p.settings.scale]
        << " | " << p.settings.bpm << " BPM | 8 bars | Seed " << p.settings.seed << "\n";
    out << "Chords: "; for (const auto& ch:p.chords) out << ch << "  ";
    out << "\n";
    for (int i=0;i<kTracks;++i) {
        int count=0;for (auto& n:p.notes) if(n.track==i)++count;
        out << "  " << trackNames[i] << ": " << count << " notes\n";
    }
    return out.str();
}
static void be32(std::vector<uint8_t>& out, uint32_t v) {
    for(int i=3;i>=0;--i) out.push_back((uint8_t)(v>>(i*8)));
}
static void be16(std::vector<uint8_t>& out, unsigned v) {
    out.push_back(uint8_t(v>>8));out.push_back(uint8_t(v));
}
static void var(std::vector<uint8_t>& o,uint32_t n) {
    uint8_t b[5];int i=0;b[i++]=n&127;
    while((n>>=7)!=0) b[i++]=(n&127)|128;
    while(i) o.push_back(b[--i]);
}
struct MidiEv { int tick,order;std::vector<uint8_t> data; };
static void chunk(std::vector<uint8_t>& out,const std::vector<MidiEv>& events) {
    auto ev=events;
    std::stable_sort(ev.begin(),ev.end(),[](const MidiEv&a,const MidiEv&b){
        return a.tick!=b.tick?a.tick<b.tick:a.order<b.order; });
    std::vector<uint8_t> data;int last=0;
    for(const auto& e:ev) {
        var(data,(uint32_t)std::max(0,e.tick-last));last=e.tick;
        data.insert(data.end(),e.data.begin(),e.data.end());
    }
    var(data,0);data.insert(data.end(),{0xFF,0x2F,0});
    out.insert(out.end(),{'M','T','r','k'});be32(out,(uint32_t)data.size());
    out.insert(out.end(),data.begin(),data.end());
}
std::vector<uint8_t> exportMidi(const Pattern& p,int onlyTrack) {
    std::vector<uint8_t> o={'M','T','h','d'};be32(o,6);be16(o,1);
    const int tracks=onlyTrack>=0?2:kTracks+1;
    be16(o,tracks);be16(o,kPPQ);
    const int us=60000000 / std::max(1,p.settings.bpm);
    chunk(o,{{0,0,{0xFF,0x51,3,(uint8_t)(us>>16),(uint8_t)(us>>8),(uint8_t)us}},
             {0,1,{0xFF,0x58,4,4,2,24,8}}});
    for(int t=0;t<kTracks;++t) {
        if(onlyTrack>=0 && onlyTrack!=t) continue;
        const auto* name=trackNames[t]; const size_t len=strlen(name);
        std::vector<uint8_t> title={0xFF,0x03,(uint8_t)len};
        title.insert(title.end(),name,name+len);
        std::vector<MidiEv> ev={{0,0,title}};
        // Avoid GM percussion channel 10. With 16 pitched tracks, one MIDI channel
        // must be reused; each instrument still has its own independent Type-1 track.
        const int ch=t<9 ? t : (t<15?t+1:0);
        const int program[kTracks]={38,0,1,24,48,9,81,52,53,54,88,10,38,80,98,12};
        ev.push_back({0,1,{(uint8_t)(0xC0+ch),(uint8_t)program[t]}});
        for(const auto& n:p.notes) if(n.track==t) {
            int on=std::clamp((int)std::llround(n.beat*kPPQ),0,kBars*4*kPPQ-1);
            int off=std::clamp((int)std::llround((n.beat+n.duration)*kPPQ),on+1,kBars*4*kPPQ);
            ev.push_back({on,3,{(uint8_t)(0x90+ch),(uint8_t)n.pitch,(uint8_t)n.velocity}});
            ev.push_back({off,2,{(uint8_t)(0x80+ch),(uint8_t)n.pitch,0}});
        }
        chunk(o,ev);
    }
    return o;
}
bool writeBinary(const std::string& path,const std::vector<uint8_t>& bytes){
    std::ofstream f(path,std::ios::binary);if(!f)return false;
    f.write(reinterpret_cast<const char*>(bytes.data()),(std::streamsize)bytes.size());
    return f.good();
}
// 8192-step wavetable with linear interpolation; avoids thousands of
// transcendental calls per audio block during dense 16-layer arrangements.
static float fastSin(double radians){
    static const auto wavetable=[] {
        std::array<float,8193> table{};
        for(int i=0;i<=8192;++i)table[i]=(float)std::sin(i*(2*pi/8192.));
        return table;
    }();
    const double cycles=radians*(1./(2*pi));
    const double scaled=(cycles-std::floor(cycles))*8192.;
    const int index=(int)scaled;
    const double frac=scaled-index;
    return (float)(wavetable[index]+(wavetable[index+1]-wavetable[index])*frac);
}
static double fastDecay(double t,double rate){
    const double x=std::max(0.,t)*rate;
    return 1./(1.+x+.48*x*x); // cheap, monotonic smooth envelope
}
static float envelope(int track,int patch,double t,double gate) {
    if(t<0)return 0;
    static constexpr double attack[kTracks]={.005,.008,.007,.004,.46,.003,.018,
        .21,.009,.007,.62,.004,.012,.018,.08,.005};
    static constexpr double release[kTracks]={.14,.34,.27,.24,1.,.75,.17,
        .62,.15,.21,1.8,.17,.23,.30,1.4,.23};
    static constexpr double decay[kTracks]={.85,1.40,.87,.38,5.,1.12,.9,
        5.,.41,.24,7.,.52,2.0,1.9,6.0,.42};
    const double a=attack[track]*(patch==2?1.2:1.);
    const double r=release[track]*(patch==1?.88:1.);
    double env=std::min(1.,t/std::max(.0001,a))*fastDecay(t,1./decay[track]);
    if(t>gate) env*=fastDecay(t-gate,5./r);
    if(t>gate+r*8.5)return 0;
    return (float)env;
}
static float pseudoNoise(double x){
    // Deterministic band-limited-ish modulation; no external samples/assets.
    return (float)(.45*fastSin(x*1031.17)*fastSin(x*779.41)
                 +.25*fastSin(x*643.11+1.7)*fastSin(x*929.31));
}
static float vowel(double phase,double time,int patch){
    // Four pitched formant-like partials; deliberately synthetic, not recorded voice.
    const double h1=2.0+(patch%2)*.15, h2=3.0+(patch/2)*.14;
    return (float)(.44*fastSin(phase)+.31*fastSin(h1*phase+.34*fastSin(4*time))
           +.18*fastSin(h2*phase)+.07*fastSin((5.+patch*.17)*phase));
}
static float tone(int track,int patch,double freq,double time){
    const double phase=2*pi*freq*time;
    const double p=patch;
    const double det=1.+.003*(p+1);
    switch(track){
        case 0: return (float)(.84*fastSin(phase)+(.11+p*.045)*fastSin(2*phase));
        case 1: return (float)(.67*fastSin(phase)+.24*fastSin(2*phase)*fastDecay(time,1.6+p*.2)+.09*fastSin(3*phase)*fastDecay(time,3));
        case 2: return (float)(.48*fastSin(phase)+.37*fastSin(2*phase)*fastDecay(time,.8)+(.15+p*.02)*fastSin(4*phase)*fastDecay(time,1.3));
        case 3: return (float)(.55*fastSin(phase)+.23*fastSin(2*phase)*fastDecay(time,5)+.14*fastSin(3*phase)*fastDecay(time,7)+.08*fastSin((5.+p*.07)*phase)*fastDecay(time,9));
        case 4: return (float)(.43*fastSin(phase)+.26*fastSin(phase*det)+.21*fastSin(phase*(2.-det))+.10*fastSin(2*phase));
        case 5: return (float)(.46*fastSin(phase+(2.8+p*.3)*fastSin(phase*1.41)*fastDecay(time,2.1))+.25*fastSin(phase*(2.76+p*.09))*fastDecay(time,.9)+.29*fastSin(phase*3.9)*fastDecay(time,3.4));
        case 6: return (float)(.70*fastSin(phase+.15*fastSin(phase*.013))+.2*fastSin((3.+p*.03)*phase)+.1*fastSin(5*phase));
        case 7: return (float)(vowel(phase,time,patch)*(.73+.15*fastSin(2*pi*4.2*time))+.045*pseudoNoise(time));
        case 8: return (float)(vowel(phase,time,patch)*fastDecay(time,.35+p*.12)+.08*pseudoNoise(time)*fastDecay(time,4));
        case 9: return (float)(vowel(phase,time,patch)*(.9+.10*fastSin(2*pi*7*time))+ .035*pseudoNoise(time));
        case 10:return (float)(.48*fastSin(phase)+.28*fastSin(phase*det)+.18*fastSin(phase*(2.-det))+.06*pseudoNoise(time));
        case 11:return (float)(.42*fastSin(phase)+.27*fastSin(2*phase)*fastDecay(time,2)+.22*fastSin(3*phase)+.09*fastSin(5*phase));
        case 12:return (float)(.37*fastSin(phase)+.33*fastSin(phase*det)+.21*fastSin(phase*(2.-det))+.09*fastSin(2*phase));
        case 13:return (float)(.38*fastSin(phase)+.33*fastSin(phase*det)+.19*fastSin(2*phase)+.10*fastSin(4*phase));
        case 14:return (float)(.46*fastSin(phase)*fastSin(phase*.007+.6)+.22*fastSin(phase*2.713)+.20*pseudoNoise(time*.35)+.12*fastSin(phase*1.007));
        case 15:return (float)(.62*fastSin(phase)+.20*fastSin(phase*2.01)*fastDecay(time,6)+.12*fastSin(phase*3.99)*fastDecay(time,8)+.06*fastSin(phase*6)*fastDecay(time,11));
        default:return 0.f;
    }
}
void AudioEngine::render(float* left,float* right,int frames,double firstBeat,
            double bpm,double sampleRate,const Pattern& p,
            const std::array<float,kTracks>& gain,
            const std::array<bool,kTracks>& mute,float master) const {
    if(!left||!right||frames<=0||sampleRate<=0||bpm<=0)return;
    constexpr float pans[kTracks]={0.0f,-.30f,.27f,.50f,-.16f,.60f,-.04f,
         -.18f,.14f,.48f,-.35f,.38f,.02f,.23f,-.48f,.44f};
    constexpr float base[kTracks]={.29f,.12f,.13f,.12f,.085f,.10f,.11f,
         .090f,.08f,.085f,.085f,.075f,.105f,.09f,.07f,.08f};
    const double beatsPerSample=bpm/(60.*sampleRate);
    const double endBeat=firstBeat+frames*beatsPerSample;
    for(const Note& n:p.notes) {
        if(mute[n.track] || gain[n.track]<=0)continue;
        const double freq=440*std::pow(2.,(n.pitch-69)/12.);
        const double relSec[kTracks]={.14,.34,.27,.24,1.0,.75,.17,
           .62,.15,.21,1.8,.17,.23,.30,1.4,.23};
        const int patch=p.settings.patches[n.track];
        const double gate=n.duration*60./bpm;
        const double tailBeats=(gate+relSec[n.track]*9)*bpm/60.;
        // Include previous loop's notes so reverb-like string release crosses bar eight.
        int kmin=(int)std::floor((firstBeat-n.beat-tailBeats)/kLoopBeats);
        int kmax=(int)std::ceil((endBeat-n.beat)/kLoopBeats);
        for(int cycle=kmin;cycle<=kmax;++cycle) {
            double noteBeat=n.beat+cycle*kLoopBeats;
            if(noteBeat>=endBeat || noteBeat+tailBeats<=firstBeat) continue;
            int start=std::max(0,(int)std::floor((noteBeat-firstBeat)/beatsPerSample));
            int end=std::min(frames,(int)std::ceil((noteBeat+tailBeats-firstBeat)/beatsPerSample));
            double amp=base[n.track]*gain[n.track]*(n.velocity/110.)*master;
            const double L=std::sqrt((1-pans[n.track])*.5);
            const double R=std::sqrt((1+pans[n.track])*.5);
            for(int i=start;i<end;++i){
                double age=(firstBeat+i*beatsPerSample-noteBeat)*60./bpm;
                if(age<0)continue;
                float e=envelope(n.track,patch,age,gate);
                if(e<1.e-5f)continue;
                float x=(float)(tone(n.track,patch,freq,age)*amp*e);
                left[i]+=(float)(x*L);
                right[i]+=(float)(x*R);
            }
        }
    }
    // Smooth soft saturation keeps dense voicings controlled, without hard clipping.
    for(int i=0;i<frames;++i) { left[i]=std::tanh(left[i]*.9f);right[i]=std::tanh(right[i]*.9f); }
}
static void le16(std::vector<uint8_t>& o,unsigned v){o.push_back(v&255);o.push_back((v>>8)&255);}
static void le32(std::vector<uint8_t>& o,uint32_t v){
    for(int i=0;i<4;++i)o.push_back((v>>(8*i))&255);
}
std::vector<uint8_t> AudioEngine::renderWav(const Pattern& p,int rate,int onlyTrack) {
    rate=std::clamp(rate,8000,96000);
    const int total=(int)std::ceil((kLoopBeats*60./p.settings.bpm+1.25)*rate);
    std::vector<uint8_t> out;out.reserve(44+(size_t)total*4);
    out.insert(out.end(),{'R','I','F','F'});le32(out,36+total*4);
    out.insert(out.end(),{'W','A','V','E','f','m','t',' '});le32(out,16);
    le16(out,1);le16(out,2);le32(out,rate);le32(out,rate*4);le16(out,4);le16(out,16);
    out.insert(out.end(),{'d','a','t','a'});le32(out,total*4);
    AudioEngine engine;
    std::array<float,kTracks> gains;gains.fill(1);
    std::array<bool,kTracks> mutes{};
    for(int t=0;t<kTracks;++t)mutes[t]=(onlyTrack>=0 && onlyTrack!=t);
    constexpr int block=512;
    std::array<float,block> left{},right{};
    for(int offset=0;offset<total;offset+=block) {
        int n=std::min(block,total-offset);
        left.fill(0);right.fill(0);
        engine.render(left.data(),right.data(),n,offset*(double)p.settings.bpm/(60*rate),
                      p.settings.bpm,rate,p,gains,mutes,.95f);
        for(int i=0;i<n;++i) {
            auto cv=[](float v)->unsigned {return (unsigned)((int16_t)std::lround(clampd(v,-1,1)*32767));};
            le16(out,cv(left[i]));le16(out,cv(right[i]));
        }
    }
    return out;
}
}
