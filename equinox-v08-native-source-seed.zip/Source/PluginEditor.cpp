#include "PluginEditor.h"
#include <algorithm>

namespace {
    const juce::Colour bg{0xff0b0e15}, panel{0xff151b29}, border{0xff2c3243};
    const juce::Colour gold{0xfff0be63}, text{0xffeaeefa}, mutedText{0xff8792aa};
    const juce::Colour trackColors[equinox::kTracks] = {
        {0xff52d8e2},{0xffea8f74},{0xffb398ed},{0xffe0bd76},
        {0xff70bcac},{0xffef88c8},{0xff88b6ff},{0xffc792fa},
        {0xfffe9e80},{0xffff79ac},{0xff98baed},{0xfff2c56d},
        {0xff5ed3ad},{0xffcda7f9},{0xffa5c695},{0xffcfbafa}};
    void styleLabel(juce::Label& label,juce::String name){
        label.setText(name,juce::dontSendNotification);
        label.setColour(juce::Label::textColourId,text);
        label.setFont(juce::Font(juce::FontOptions(13.f).withStyle("Bold")));
    }
    void styleSlider(juce::Slider& slider,double min,double max,double step,double value){
        slider.setSliderStyle(juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle(juce::Slider::TextBoxRight,false,56,22);
        slider.setRange(min,max,step);slider.setValue(value,juce::dontSendNotification);
        slider.setColour(juce::Slider::trackColourId,gold);
        slider.setColour(juce::Slider::thumbColourId,text);
        slider.setColour(juce::Slider::backgroundColourId,border);
        slider.setColour(juce::Slider::textBoxTextColourId,text);
        slider.setColour(juce::Slider::textBoxOutlineColourId,border);
    }
}
ForgeEditor::ForgeEditor(ForgeProcessor& p):juce::AudioProcessorEditor(&p),processor(p){
    setSize(1340,870);
    for(auto* cb : {&style,&scale,&root,&substyle}){
        addAndMakeVisible(*cb);cb->setColour(juce::ComboBox::backgroundColourId,panel);
        cb->setColour(juce::ComboBox::textColourId,text);
        cb->setColour(juce::ComboBox::outlineColourId,border);
    }
    for(int i=0;i<6;++i)style.addItem(equinox::styleNames[i],i+1);
    for(int i=0;i<5;++i)scale.addItem(equinox::scaleNames[i],i+1);
    for(int i=0;i<12;++i)root.addItem(equinox::rootNames[i],i+1);
    substyle.addItem("AUTO / DISCOVER",1);substyle.addItem("INTIMATE / SPARSE",2);
    substyle.addItem("RHYTHMIC / POCKET",3);substyle.addItem("CINEMATIC / LUSH",4);
    auto pat=processor.snapshot();auto s=pat->settings;
    style.setSelectedId((int)s.style+1,juce::dontSendNotification);
    scale.setSelectedId((int)s.scale+1,juce::dontSendNotification);
    root.setSelectedId(s.root+1,juce::dontSendNotification);
    substyle.setSelectedId(s.substyle+2,juce::dontSendNotification);
    styleSlider(tempo,65,195,1,s.bpm);styleSlider(density,5,100,1,s.density*100);
    styleSlider(swing,0,45,1,s.swing*100);styleSlider(emotion,0,100,1,s.emotion*100);
    styleSlider(vocalAmount,0,100,1,s.vocalAmount*100);
    styleSlider(atmosphere,0,100,1,s.atmosphere*100);
    styleSlider(master,0,150,1,processor.getMaster()*100);
    for(auto* slider : {&tempo,&density,&swing,&emotion,&vocalAmount,&atmosphere,&master})addAndMakeVisible(*slider);
    auto onSettings=[this]{applyControls();};
    style.onChange=[this]{applyControls(true);};
    scale.onChange=onSettings;root.onChange=onSettings;substyle.onChange=onSettings;
    tempo.onValueChange=onSettings;density.onValueChange=onSettings;
    swing.onValueChange=onSettings;emotion.onValueChange=onSettings;
    vocalAmount.onValueChange=onSettings;atmosphere.onValueChange=onSettings;
    master.onValueChange=[this]{processor.setMaster((float)(master.getValue()/100));};
    for(auto* b : {&regenerateButton,&mutateButton,&playButton,&exportButton,&stemsButton}){
        addAndMakeVisible(*b);b->setColour(juce::TextButton::buttonColourId,panel);
        b->setColour(juce::TextButton::textColourOffId,text);
    }
    regenerateButton.setColour(juce::TextButton::buttonColourId,gold);
    regenerateButton.setColour(juce::TextButton::textColourOffId,bg);
    regenerateButton.onClick=[this]{
        applyControls();
        if(auto snap=processor.snapshot()){
            auto settings=snap->settings;
            settings.seed=(uint32_t)juce::Random::getSystemRandom().nextInt();
            processor.regenerate(settings);
        }
        status.setText("New eight-bar arrangement generated",juce::dontSendNotification);repaint();
    };
    mutateButton.onClick=[this]{processor.mutate();status.setText("Variation generated (new seed)",juce::dontSendNotification);repaint();};
    playButton.onClick=[this]{processor.setInternalPlay(!processor.isInternalPlaying());};
    exportButton.onClick=[this]{exportAll();};
    stemsButton.onClick=[this]{exportStems();};
    for(auto* b:{&bankA,&bankB}) {addAndMakeVisible(*b);b->setColour(juce::TextButton::textColourOffId,text);}
    bankA.onClick=[this]{currentBank=0;refreshBank();};
    bankB.onClick=[this]{currentBank=1;refreshBank();};
    for(int i=0;i<equinox::kTracks;++i){
        trackLabels[i].setText(equinox::trackNames[i],juce::dontSendNotification);
        styleLabel(trackLabels[i],equinox::trackNames[i]);
        trackLabels[i].setColour(juce::Label::textColourId,trackColors[i]);
        addAndMakeVisible(trackLabels[i]);
        trackMute[i].setButtonText("MUTE");addAndMakeVisible(trackMute[i]);
        loadWav[i].setButtonText("LOAD WAV");addAndMakeVisible(loadWav[i]);
        loadWav[i].setColour(juce::TextButton::buttonColourId,juce::Colour(0xff284638));
        loadWav[i].onClick=[this,i]{
            chooser=std::make_unique<juce::FileChooser>("Select an acoustic recording for " + juce::String(equinox::trackNames[i]),
                juce::File::getSpecialLocation(juce::File::userMusicDirectory),"*.wav;*.aif;*.aiff;*.flac;*.mp3");
            juce::Component::SafePointer<ForgeEditor> safe(this);
            chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,
                [safe,i](const juce::FileChooser& fc){
                    if(!safe)return;
                    const juce::File file=fc.getResult();if(!file.existsAsFile())return;
                    const bool ok=safe->processor.loadSampleForTrack(i,file);
                    safe->status.setText(ok?"RECORDED: "+file.getFileName():"Audio import failed (WAV/FLAC/AIFF preferred)",juce::dontSendNotification);
                    safe->refreshTrackUI();
                });
        };
        styleSlider(sampleRoot[i],24,96,1,processor.getSampleRoot(i));addAndMakeVisible(sampleRoot[i]);sampleRoot[i].setTooltip("Root MIDI note of imported recording. 60 = C4. Default: 60");
        sampleRoot[i].onValueChange=[this,i]{processor.setSampleRoot(i,(int)sampleRoot[i].getValue());};
        trackMute[i].setColour(juce::TextButton::buttonColourId,panel);
        const int ix=i;
        trackMute[i].onClick=[this,ix]{processor.setLayerMute(ix,!processor.isMuted(ix));refreshTrackUI();repaint();};
        styleSlider(trackVolume[i],0,150,1,processor.getLayerGain(i)*100);
        addAndMakeVisible(trackVolume[i]);
        trackVolume[i].onValueChange=[this,ix]{processor.setLayerGain(ix,(float)(trackVolume[ix].getValue()/100));};
        for(int j=0;j<4;++j)trackPatch[i].addItem(equinox::patchNames[i][j],j+1);
        trackPatch[i].setSelectedId(s.patches[i]+1,juce::dontSendNotification);
        trackPatch[i].setColour(juce::ComboBox::backgroundColourId,panel);
        trackPatch[i].setColour(juce::ComboBox::textColourId,text);
        trackPatch[i].setColour(juce::ComboBox::outlineColourId,border);
        addAndMakeVisible(trackPatch[i]);
        trackPatch[i].onChange=[this,ix]{
            auto snap=processor.snapshot();if(!snap)return;
            auto next=snap->settings;
            next.patches[ix]=juce::jlimit(0,3,trackPatch[ix].getSelectedId()-1);
            processor.regenerate(next);repaint();
        };
    }
    addAndMakeVisible(status);status.setJustificationType(juce::Justification::centredLeft);
    status.setColour(juce::Label::textColourId,mutedText);
    status.setText("16 layers • load real WAV on each layer • MIDI export • DAW sync",juce::dontSendNotification);
    refreshTrackUI();refreshBank();startTimerHz(20);
}
void ForgeEditor::applyControls(bool resetTempo){
    auto p=processor.snapshot();if(!p)return;auto s=p->settings;
    s.style=(equinox::Style)juce::jlimit(0,5,style.getSelectedId()-1);
    s.scale=(equinox::Scale)juce::jlimit(0,4,scale.getSelectedId()-1);
    s.root=juce::jlimit(0,11,root.getSelectedId()-1);
    s.substyle=juce::jlimit(-1,2,substyle.getSelectedId()-2);
    if(resetTempo){tempo.setValue(equinox::defaultBpm(s.style),juce::dontSendNotification);}
    s.bpm=(int)tempo.getValue();s.density=density.getValue()/100.;
    s.swing=swing.getValue()/100.;s.emotion=emotion.getValue()/100.;
    s.vocalAmount=vocalAmount.getValue()/100.;s.atmosphere=atmosphere.getValue()/100.;
    processor.regenerate(s);repaint();
}
void ForgeEditor::refreshTrackUI(){
    for(int i=0;i<equinox::kTracks;++i){
        trackMute[i].setColour(juce::TextButton::buttonColourId,
            processor.isMuted(i)?juce::Colour(0xff663949):panel);
        trackMute[i].setButtonText(processor.isMuted(i)?"UNMUTE":"MUTE");
        loadWav[i].setButtonText(processor.hasLoadedSample(i)?"WAV ✓":"LOAD WAV");
    }
}
void ForgeEditor::refreshBank(){
    for(int i=0;i<equinox::kTracks;++i){
        const bool visible=(i/8)==currentBank;
        trackLabels[i].setVisible(visible);trackMute[i].setVisible(visible);
        trackVolume[i].setVisible(visible);trackPatch[i].setVisible(visible);loadWav[i].setVisible(visible);sampleRoot[i].setVisible(visible);
    }
    bankA.setColour(juce::TextButton::buttonColourId,currentBank==0?gold:panel);
    bankA.setColour(juce::TextButton::textColourOffId,currentBank==0?bg:text);
    bankB.setColour(juce::TextButton::buttonColourId,currentBank==1?gold:panel);
    bankB.setColour(juce::TextButton::textColourOffId,currentBank==1?bg:text);
    resized();repaint();
}
void ForgeEditor::timerCallback(){
    playButton.setColour(juce::TextButton::buttonColourId,
       processor.isInternalPlaying()?juce::Colour(0xff285349):panel);
    if(rollRect.getWidth()>0)repaint(rollRect);
}
void ForgeEditor::exportAll(){
    chooser=std::make_unique<juce::FileChooser>("Save your 8-bar MIDI",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("EQUINOX_8BAR_LOOP.mid"),"*.mid");
    juce::Component::SafePointer<ForgeEditor> safe(this);
    chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles,
    [safe](const juce::FileChooser& fc){
        if(!safe)return;
        juce::File f=fc.getResult();if(f.getFullPathName().isEmpty())return;
        if(f.getFileExtension().toLowerCase()!=".mid")f=f.withFileExtension(".mid");
        bool ok=safe->processor.exportMidiFile(f);
        safe->status.setText(ok?"Exported multitrack MIDI: "+f.getFileName():"MIDI export failed",juce::dontSendNotification);
    });
}
void ForgeEditor::exportStems(){
    chooser=std::make_unique<juce::FileChooser>("Choose a folder for sixteen MIDI layers",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory));
    juce::Component::SafePointer<ForgeEditor> safe(this);
    chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectDirectories,
    [safe](const juce::FileChooser& fc){
        if(!safe)return;
        auto folder=fc.getResult();if(!folder.isDirectory())return;
        bool ok=true;
        for(int i=0;i<equinox::kTracks;++i){
            juce::String name=equinox::trackNames[i];name=name.replaceCharacter(' ','_');
            ok=safe->processor.exportMidiFile(folder.getChildFile("EQUINOX_"+name+".mid"),i)&&ok;
        }
        safe->status.setText(ok?"Exported 16 separate MIDI layers":"Some layer exports failed",juce::dontSendNotification);
    });
}
void ForgeEditor::resized(){
    const int w=getWidth();
    style.setBounds(28,92,200,32);
    root.setBounds(242,92,110,32);
    scale.setBounds(365,92,205,32);
    substyle.setBounds(588,92,260,32);
    const int cols=7,cw=(w-56)/cols;
    juce::Slider* sl[]={&tempo,&density,&swing,&emotion,&vocalAmount,&atmosphere,&master};
    for(int i=0;i<cols;++i)sl[i]->setBounds(28+i*cw,164,cw-10,34);
    int btnX=28;
    for(auto* b:{&regenerateButton,&mutateButton,&playButton,&exportButton,&stemsButton}){
        int wide=(b==&exportButton?242:(b==&stemsButton?224:151));
        b->setBounds(btnX,229,wide,42);btnX+=wide+11;
    }
    chordRect={28,310,w-56,44};
    rollRect={565,398,w-593,368};
    bankA.setBounds(29,365,150,27);bankB.setBounds(187,365,150,27);
    for(int i=0;i<equinox::kTracks;++i){
        const int y=399+(i%8)*46;
        trackLabels[i].setBounds(29,y,143,22);
        trackVolume[i].setBounds(30,y+20,159,24);
        trackPatch[i].setBounds(189,y,155,26);
        sampleRoot[i].setBounds(346,y,86,26);
        trackMute[i].setBounds(434,y,60,25);
        loadWav[i].setBounds(497,y,63,25);
    }
    status.setBounds(28,793,w-56,27);
}
void ForgeEditor::paint(juce::Graphics& g){
    g.fillAll(bg);
    auto w=getWidth();
    g.setColour(gold);
    g.setFont(juce::Font(juce::FontOptions(28.f).withStyle("Bold")));
    g.drawText("EQUINOX",28,22,260,43,juce::Justification::centredLeft);
    g.setColour(text);g.setFont(22);
    g.drawText("MELODY FORGE",194,26,310,33,juce::Justification::centredLeft);
    g.setColour(mutedText);g.setFont(13);
    g.drawText("16-LAYER COMPOSER  /  RECORDED WAV SAMPLER  /  CHOIR • CHANTS • VOCAL CHOPS • PADS • ARPS • BASS",28,64,w-56,25,juce::Justification::centredLeft);
    g.setFont(12);g.setColour(mutedText);
    g.drawText("GENRE",28,77,120,16,juce::Justification::centredLeft);
    g.drawText("KEY",242,77,100,16,juce::Justification::centredLeft);
    g.drawText("SCALE",365,77,150,16,juce::Justification::centredLeft);
    g.drawText("PRODUCER PROFILE",588,77,190,16,juce::Justification::centredLeft);
    const char* labels[]={"TEMPO (BPM)","DENSITY","SWING %","EMOTION","VOCALS %","ATMOSPHERE %","MASTER %"};
    int cw=(w-56)/7;
    for(int i=0;i<7;++i)g.drawText(labels[i],28+i*cw,143,cw-15,17,juce::Justification::centredLeft);
    g.setColour(border);g.drawLine(28,290,w-28,290,1);
    g.setFont(12);g.setColour(mutedText);
    g.drawText("EIGHT BAR HARMONY",28,289,w-56,18,juce::Justification::centredLeft);
    auto pattern=processor.snapshot();if(!pattern)return;
    auto r=chordRect;
    for(int i=0;i<8;++i){
        float bw=r.getWidth()/8.f;
        juce::Rectangle<float> rect(r.getX()+i*bw,r.getY(),bw-4.f,r.getHeight());
        g.setColour(i%2?juce::Colour(0xff192032):panel);g.fillRoundedRectangle(rect,7);
        g.setColour(gold);g.setFont(14);
        g.drawText(pattern->chords[i],(int)rect.getX()+6,(int)rect.getY()+9,(int)rect.getWidth()-12,26,juce::Justification::centred);
        g.setColour(mutedText);g.setFont(10);
        g.drawText("BAR "+juce::String(i+1),(int)rect.getX()+6,(int)rect.getY()+2,(int)rect.getWidth()-12,13,juce::Justification::centred);
    }
    auto v=rollRect.toFloat();g.setColour(panel);g.fillRoundedRectangle(v,9);
    const float rowHeight=v.getHeight()/equinox::kTracks;
    for(int i=0;i<equinox::kTracks;++i){
        float rowY=v.getY()+i*rowHeight;
        if(i>0){g.setColour(border);g.drawLine(v.getX(),rowY,v.getRight(),rowY,.55f);}
        for(int bar=0;bar<8;++bar){
            float xx=v.getX()+bar*(v.getWidth()/8.f);
            g.setColour(bar%2?juce::Colour(0xff111827):juce::Colour(0xff1a2334));
            g.fillRect(xx,rowY,v.getWidth()/8.f,rowHeight-.5f);
            g.setColour(juce::Colour(0xff334058));g.drawLine(xx,rowY,xx,rowY+rowHeight,.6f);
        }
    }
    for(const auto& n:pattern->notes){
        const int track=n.track;
        const float rowY=v.getY()+track*rowHeight;
        const float xx=v.getX()+(float)(n.beat/32.)*v.getWidth();
        const float noteW=std::max(2.0f,(float)(n.duration/32.)*v.getWidth());
        const float yn=(float)juce::jmap((float)n.pitch,24.f,99.f,rowHeight-5.f,2.f);
        g.setColour(processor.isMuted(track)?mutedText.withAlpha(.25f):trackColors[track].withAlpha(.82f));
        g.fillRoundedRectangle(xx,rowY+yn,noteW,3.2f,1.4f);
    }
    double b=processor.getDisplayBeat();
    if(processor.isInternalPlaying()||b!=0){
        const float px=v.getX()+(float)(b/32.)*v.getWidth();
        g.setColour(gold.withAlpha(.80f));g.drawLine(px,v.getY(),px,v.getBottom(),1.6f);
    }
    g.setColour(mutedText);g.setFont(11);
    g.drawText("FL STUDIO: export 16 separate MIDI layers for full sound assignment • LOAD WAV to replace synth with your own recorded samples",28,833,w-56,24,juce::Justification::centredLeft);
}
