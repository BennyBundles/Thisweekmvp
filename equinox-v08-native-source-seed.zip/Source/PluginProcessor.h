#pragma once
#include <JuceHeader.h>
#include "MelodyCore.h"
#include <array>
#include <atomic>
#include <memory>

class ForgeProcessor final : public juce::AudioProcessor {
public:
    ForgeProcessor();
    ~ForgeProcessor() override = default;
    void prepareToPlay(double sampleRate,int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layout) const override;
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override {return true;}
    const juce::String getName() const override {return "EQUINOX Melody Forge";}
    bool acceptsMidi() const override {return true;}
    bool producesMidi() const override {return true;}
    bool isMidiEffect() const override {return false;}
    double getTailLengthSeconds() const override {return 1.0;}
    int getNumPrograms() override{return 1;}
    int getCurrentProgram() override{return 0;}
    void setCurrentProgram(int) override{}
    const juce::String getProgramName(int) override{return "Custom Eight Bars";}
    void changeProgramName(int,const juce::String&) override{}
    void getStateInformation(juce::MemoryBlock& dest) override;
    void setStateInformation(const void* data,int bytes) override;
    std::shared_ptr<const equinox::Pattern> snapshot() const {return std::atomic_load(&pattern);}
    void regenerate(equinox::Settings newSettings);
    void mutate();
    std::array<float,equinox::kTracks> layerGains() const;
    std::array<bool,equinox::kTracks> layerMutes() const;
    void setLayerGain(int idx,float value);
    void setLayerMute(int idx,bool value);
    bool isMuted(int idx) const;
    float getLayerGain(int idx) const;
    void setMaster(float value) {master.store(juce::jlimit(0.f,1.5f,value));}
    float getMaster() const {return master.load();}
    void setInternalPlay(bool value);
    bool isInternalPlaying() const {return internalPlay.load();}
    double getDisplayBeat() const {return displayBeat.load();}
    bool exportMidiFile(const juce::File& file,int onlyTrack=-1) const;
    // WAV sample playback. Files are loaded off the audio thread.
    bool loadSampleForTrack(int track,const juce::File& file);
    void clearSampleForTrack(int track);
    bool hasLoadedSample(int track) const;
    juce::String sampleFileName(int track) const;
    void setSampleRoot(int track,int midi);
    int getSampleRoot(int track) const;

private:
    struct RecordedNote {
        juce::AudioBuffer<float> audio;
        double sourceRate=44100.;
        juce::String sourcePath;
    };
    std::array<std::shared_ptr<const RecordedNote>,equinox::kTracks> samples{}; // user overrides
    // [track][timbre variation][pitch zone][soft/loud velocity layer]. Immutable after construction.
    std::array<std::array<std::array<std::array<std::shared_ptr<const RecordedNote>,2>,5>,2>,equinox::kTracks> factoryBank{};
    void loadFactoryBank();
    static std::shared_ptr<const RecordedNote> readSampleFile(const juce::File& file);
    std::array<std::atomic<int>,equinox::kTracks> sampleRoots{};
    void renderRecorded(juce::AudioBuffer<float>& dest,int samplesInBlock,double beat,double bpm,double sr,
                       const equinox::Pattern& p,const std::array<float,equinox::kTracks>& levels,
                       const std::array<bool,equinox::kTracks>& trackMutes);
    mutable std::shared_ptr<const equinox::Pattern> pattern;
    equinox::AudioEngine synthesizer;
    std::array<std::atomic<float>,equinox::kTracks> gain;
    std::array<std::atomic<bool>,equinox::kTracks> mute;
    std::atomic<float> master{.8f};
    std::atomic<bool> internalPlay{false};
    std::atomic<bool> flushMidi{false};
    std::atomic<double> displayBeat{0};
    double internalBeat=0; // only accessed from audio thread; free-running preview clock
    bool previouslyPlaying=false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ForgeProcessor)
};
