#pragma once
#include "PluginProcessor.h"
#include <JuceHeader.h>
#include <array>
#include <memory>

class ForgeEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit ForgeEditor(ForgeProcessor&);
    ~ForgeEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    ForgeProcessor& processor;
    juce::ComboBox style, scale, root, substyle;
    juce::Slider tempo, density, swing, emotion, vocalAmount, atmosphere, master;
    juce::TextButton regenerateButton{"GENERATE"}, mutateButton{"MUTATE"};
    juce::TextButton playButton{"PLAY / STOP"}, exportButton{"EXPORT MULTITRACK MIDI"};
    juce::TextButton stemsButton{"EXPORT 16 MIDI LAYERS"};
    juce::TextButton bankA{"BANK A  ·  1–8"}, bankB{"BANK B  ·  9–16"};
    int currentBank = 0;
    std::array<juce::Slider,equinox::kTracks> trackVolume;
    std::array<juce::ComboBox,equinox::kTracks> trackPatch;
    std::array<juce::TextButton,equinox::kTracks> trackMute;
    std::array<juce::TextButton,equinox::kTracks> loadWav;
    std::array<juce::Slider,equinox::kTracks> sampleRoot;
    std::array<juce::Label,equinox::kTracks> trackLabels;
    juce::Label status;
    juce::Rectangle<int> rollRect, chordRect;
    void applyControls(bool resetTempo=false);
    void refreshTrackUI();
    void refreshBank();
    void timerCallback() override;
    void exportAll();
    void exportStems();
    std::unique_ptr<juce::FileChooser> chooser;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ForgeEditor)
};
