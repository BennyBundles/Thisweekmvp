#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SampleTimeline.h"
#include <cmath>

ForgeProcessor::ForgeProcessor()
: juce::AudioProcessor(BusesProperties().withOutput("Output",juce::AudioChannelSet::stereo(),true)) {
    for(int t=0;t<equinox::kTracks;++t){gain[t].store(1.f);mute[t].store(false);sampleRoots[t].store(60);}
    equinox::Settings s;
    std::atomic_store(&pattern,std::make_shared<const equinox::Pattern>(equinox::generate(s)));
    loadFactoryBank();
}
void ForgeProcessor::prepareToPlay(double,int){internalBeat=0;previouslyPlaying=false;}
bool ForgeProcessor::isBusesLayoutSupported(const BusesLayout& l) const {
    return l.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();
}
void ForgeProcessor::regenerate(equinox::Settings s){
    std::atomic_store(&pattern,std::make_shared<const equinox::Pattern>(equinox::generate(s)));
    flushMidi.store(true);
}
void ForgeProcessor::mutate(){
    auto current=snapshot(); if(!current)return;
    auto s=current->settings;s.seed+=0x9e3779b9u;regenerate(s);
}
void ForgeProcessor::setInternalPlay(bool value){
    internalPlay.store(value);
    // Only audio thread updates internalBeat, no unsafe UI reset.
}
std::array<float,equinox::kTracks> ForgeProcessor::layerGains() const {
    std::array<float,equinox::kTracks> out{};
    for(int i=0;i<equinox::kTracks;++i)out[i]=gain[i].load();return out;
}
std::array<bool,equinox::kTracks> ForgeProcessor::layerMutes() const {
    std::array<bool,equinox::kTracks> out{};
    for(int i=0;i<equinox::kTracks;++i)out[i]=mute[i].load();return out;
}
void ForgeProcessor::setLayerGain(int idx,float v){
    if(idx>=0&&idx<equinox::kTracks)gain[idx].store(juce::jlimit(0.f,1.5f,v));
}
void ForgeProcessor::setLayerMute(int idx,bool v){
    if(idx>=0&&idx<equinox::kTracks)mute[idx].store(v);
}
bool ForgeProcessor::isMuted(int idx) const {return idx>=0&&idx<equinox::kTracks?mute[idx].load():false;}
float ForgeProcessor::getLayerGain(int idx) const {return idx>=0&&idx<equinox::kTracks?gain[idx].load():1.f;}
void ForgeProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    auto pat=snapshot();if(!pat||buffer.getNumChannels()<2)return;
    const double sr=getSampleRate();const int size=buffer.getNumSamples();
    if(size<=0||sr<=0)return;
    bool hostIsPlaying=false;double bpm=(double)pat->settings.bpm;
    double beat=internalBeat;
    if(auto* head=getPlayHead()){
        if(auto info=head->getPosition()){
            if(auto b=info->getBpm()) if(*b>=30 && *b<=300) bpm=*b;
            hostIsPlaying=info->getIsPlaying().value_or(false);
            if(hostIsPlaying) if(auto ppq=info->getPpqPosition()) beat=*ppq;
        }
    }
    if(flushMidi.exchange(false))
        for(int ch=1;ch<=16;++ch)midi.addEvent(juce::MidiMessage::allNotesOff(ch),0);
    const bool playing=hostIsPlaying||internalPlay.load();
    if(!playing){
        if(previouslyPlaying) for(int ch=1;ch<=16;++ch)
            midi.addEvent(juce::MidiMessage::allNotesOff(ch),0);
        previouslyPlaying=false;
        displayBeat.store(0);
        return;
    }
    previouslyPlaying=true;
    if(!hostIsPlaying) beat=internalBeat;
    const double beatsPerSample=bpm/(60.0*sr);
    const double end=beat+size*beatsPerSample;
    // MIDI follows DAW clock when transport runs; generated output can feed another instrument.
    // No heap allocation per note; the immutable pattern is shared via atomic snapshot.
    for(const auto& note:pat->notes){
        const bool trackMuted=mute[note.track].load();
        const int channel=(note.track<9?note.track+1:(note.track<15?note.track+2:1));
        auto schedule=[&](double eventBeat,bool isOn){
            const int k0=(int)std::floor((beat-eventBeat)/equinox::kLoopBeats);
            const int k1=(int)std::ceil((end-eventBeat)/equinox::kLoopBeats);
            for(int k=k0;k<=k1;++k){
                double absolute=eventBeat+k*equinox::kLoopBeats;
                if(absolute<beat-0.0000001||absolute>=end)continue;
                const int sample=juce::jlimit(0,size-1,(int)std::floor((absolute-beat)/beatsPerSample+.000001));
                midi.addEvent(isOn ? juce::MidiMessage::noteOn(channel,note.pitch,(juce::uint8)note.velocity)
                                   : juce::MidiMessage::noteOff(channel,note.pitch),sample);
            }
        };
        if(!trackMuted)schedule(note.beat,true);
        schedule(note.beat+note.duration,false);
    }
    auto levels=layerGains();auto trackMutes=layerMutes();auto fallbackMutes=trackMutes;
    for(int t=0;t<equinox::kTracks;++t)
        if(std::atomic_load(&samples[t]) ||
           (pat->settings.patches[t]<2 && factoryBank[t][pat->settings.patches[t]][0][0]))
            fallbackMutes[t]=true;
    synthesizer.render(buffer.getWritePointer(0),buffer.getWritePointer(1),size,
             beat,bpm,sr,*pat,levels,fallbackMutes,master.load());
    renderRecorded(buffer,size,beat,bpm,sr,*pat,levels,trackMutes);
    displayBeat.store(std::fmod(std::fmod(beat,equinox::kLoopBeats)+equinox::kLoopBeats,equinox::kLoopBeats));
    internalBeat+=size*beatsPerSample;
    if(internalBeat>1.e8)internalBeat=std::fmod(internalBeat,equinox::kLoopBeats);
}
bool ForgeProcessor::exportMidiFile(const juce::File& f,int onlyTrack) const {
    auto p=snapshot();if(!p)return false;
    auto bytes=equinox::exportMidi(*p,onlyTrack);
    if(!f.deleteFile() && f.existsAsFile())return false;
    juce::FileOutputStream s(f);if(!s.openedOk())return false;
    return s.write(bytes.data(),bytes.size());
}
void ForgeProcessor::getStateInformation(juce::MemoryBlock& out){
    auto p=snapshot();if(!p)return;
    const auto& s=p->settings;
    juce::XmlElement root("EQUINOX_Melody_Forge");
    root.setAttribute("version",4);root.setAttribute("style",(int)s.style);
    root.setAttribute("scale",(int)s.scale);root.setAttribute("root",s.root);
    root.setAttribute("bpm",s.bpm);root.setAttribute("seed",juce::String((juce::int64)s.seed));
    root.setAttribute("density",s.density);root.setAttribute("swing",s.swing);
    root.setAttribute("substyle",s.substyle);
    root.setAttribute("emotion",s.emotion);
    root.setAttribute("vocalAmount",s.vocalAmount);root.setAttribute("atmosphere",s.atmosphere);
    root.setAttribute("master",(double)master.load());
    for(int t=0;t<equinox::kTracks;++t){
        root.setAttribute("gain"+juce::String(t),(double)gain[t].load());
        root.setAttribute("mute"+juce::String(t),mute[t].load());
        root.setAttribute("patch"+juce::String(t),s.patches[t]);
        root.setAttribute("wav"+juce::String(t),[&]{auto v=std::atomic_load(&samples[t]);return v?v->sourcePath:juce::String();}());
        root.setAttribute("noteRoot"+juce::String(t),sampleRoots[t].load());
    }
    copyXmlToBinary(root,out);
}
void ForgeProcessor::setStateInformation(const void* data,int length){
    auto xml=getXmlFromBinary(data,length);
    if(!xml||!xml->hasTagName("EQUINOX_Melody_Forge"))return;
    equinox::Settings s;
    s.style=(equinox::Style)juce::jlimit(0,5,xml->getIntAttribute("style",3));
    s.scale=(equinox::Scale)juce::jlimit(0,4,xml->getIntAttribute("scale",0));
    s.root=juce::jlimit(0,11,xml->getIntAttribute("root",9));
    s.bpm=juce::jlimit(65,195,xml->getIntAttribute("bpm",136));
    s.seed=(uint32_t)xml->getStringAttribute("seed","20261010").getLargeIntValue();
    s.density=xml->getDoubleAttribute("density",.43);
    s.swing=xml->getDoubleAttribute("swing",.12);
    s.substyle=juce::jlimit(-1,2,xml->getIntAttribute("substyle",-1));
    s.emotion=xml->getDoubleAttribute("emotion",.7);
    s.vocalAmount=xml->getDoubleAttribute("vocalAmount",.48);
    s.atmosphere=xml->getDoubleAttribute("atmosphere",.37);
    master.store((float)xml->getDoubleAttribute("master",.8));
    for(int i=0;i<equinox::kTracks;++i){
        setLayerGain(i,(float)xml->getDoubleAttribute("gain"+juce::String(i),1.));
        setLayerMute(i,xml->getBoolAttribute("mute"+juce::String(i),false));
        s.patches[i]=juce::jlimit(0,3,xml->getIntAttribute("patch"+juce::String(i),0));
        setSampleRoot(i,xml->getIntAttribute("noteRoot"+juce::String(i),60));
        auto wav=xml->getStringAttribute("wav"+juce::String(i));
        if(wav.isNotEmpty())loadSampleForTrack(i,juce::File(wav));
        else clearSampleForTrack(i);
    }
    regenerate(s);
}
juce::AudioProcessorEditor* ForgeProcessor::createEditor(){return new ForgeEditor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new ForgeProcessor();}

// The imported recording is kept immutable while rendering; changing it only
// atomically swaps the shared pointer between the editor and audio thread.
std::shared_ptr<const ForgeProcessor::RecordedNote> ForgeProcessor::readSampleFile(const juce::File& file){
    if(!file.existsAsFile()||file.getSize()>55*1024*1024LL)return {};
    juce::AudioFormatManager fm;fm.registerBasicFormats();
    auto reader=std::unique_ptr<juce::AudioFormatReader>(fm.createReaderFor(file));
    if(!reader||reader->lengthInSamples<100||reader->lengthInSamples>reader->sampleRate*40.||reader->numChannels<1)return {};
    auto next=std::make_shared<RecordedNote>();
    next->sourceRate=reader->sampleRate;
    next->sourcePath=file.getFullPathName();
    int length=(int)juce::jmin(reader->lengthInSamples,(juce::int64)(reader->sampleRate*40.));
    next->audio.setSize(2,length,false,true,true);
    if(!reader->read(&next->audio,0,length,0,true,true))return {};
    if(reader->numChannels==1)next->audio.copyFrom(1,0,next->audio,0,0,length);
    return next;
}
bool ForgeProcessor::loadSampleForTrack(int track,const juce::File& file){
    if(track<0||track>=equinox::kTracks)return false;
    auto frozen=readSampleFile(file);
    if(!frozen)return false;
    std::atomic_store(&samples[track],std::move(frozen));
    return true;
}
void ForgeProcessor::clearSampleForTrack(int track){
    if(track<0||track>=equinox::kTracks)return;
    std::atomic_store(&samples[track],std::shared_ptr<const RecordedNote>{});
}
bool ForgeProcessor::hasLoadedSample(int track) const{
    return track>=0&&track<equinox::kTracks&&bool(std::atomic_load(&samples[track])||factoryBank[track][0][0][0]);
}
juce::String ForgeProcessor::sampleFileName(int track) const{
    if(track<0||track>=equinox::kTracks)return {};
    const auto p=std::atomic_load(&samples[track]);
    return p?juce::File(p->sourcePath).getFileName():(factoryBank[track][0][0][0]?juce::String("FACTORY BANK (5 zones x 2 velocities)"):juce::String());
}
void ForgeProcessor::setSampleRoot(int track,int midi){
    if(track>=0&&track<equinox::kTracks)sampleRoots[track].store(juce::jlimit(24,96,midi));
}
int ForgeProcessor::getSampleRoot(int track) const{
    return track>=0&&track<equinox::kTracks?sampleRoots[track].load():60;
}
void ForgeProcessor::renderRecorded(juce::AudioBuffer<float>& dest,int samplesInBlock,double beat,double bpm,double sr,
                                   const equinox::Pattern& p,const std::array<float,equinox::kTracks>& levels,
                                   const std::array<bool,equinox::kTracks>& trackMutes){
    if(bpm<=0.||sr<=0.)return;
    const double samplesPerBeat=60.0*sr/bpm,sourceSecondsPerBeat=60./bpm;
    auto* left=dest.getWritePointer(0);auto* right=dest.getWritePointer(1);
    static constexpr int roots[equinox::kTracks][5] = {
       {32,36,43,48,52},{39,43,50,57,61},{56,60,67,74,78},
       {48,52,59,66,70},{51,55,62,69,73},{68,72,79,86,90},
       {60,64,71,78,82},{48,52,59,66,70},{44,48,55,62,66},
       {60,64,71,78,82},{48,52,59,66,70},{60,64,71,78,82},
       {32,36,43,50,54},{51,55,62,69,73},{56,60,67,74,78},
       {63,67,74,81,85}
    };
    for(int track=0;track<equinox::kTracks;++track){
        if(trackMutes[track]||levels[track]<.00001f)continue;
        auto user=std::atomic_load(&samples[track]);
        if(!user && (p.settings.patches[track]>1 || !factoryBank[track][p.settings.patches[track]][0][0]))continue;
        const bool sustain=track==4||track==7||track==10||track==14;
        const double maxDuration=40.;
        for(const auto& n:p.notes){
            if(n.track!=track)continue;
            auto sample=user;
            int root=sampleRoots[track].load();
            if(!sample){
                const int timbre=p.settings.patches[track];
                if(timbre>=2)continue; // 3rd/4th timbres use procedural modeling.
                const int dyn=n.velocity<88?0:1;
                int chosen=-1, distance=10000;
                for(int zone=0;zone<5;++zone){
                    if(factoryBank[track][timbre][zone][dyn]){
                        const int delta=std::abs(n.pitch-roots[track][zone]);
                        if(delta<distance){distance=delta;chosen=zone;}
                    }
                }
                if(chosen<0)continue;
                sample=factoryBank[track][timbre][chosen][dyn];root=roots[track][chosen];
            }
            const auto& audio=sample->audio;
            const int length=audio.getNumSamples();
            if(length<2)continue;
            const auto* srcL=audio.getReadPointer(0),*srcR=audio.getReadPointer(1);
            const double playbackRate=std::pow(2.,(n.pitch-root)/12.)*sample->sourceRate/sr;
            const double noteGain=(user?(n.velocity/127.f):(.73+.27*n.velocity/127.f)) *
                                  levels[track]*master.load()*.41;
            const double attack=sustain?.055:.006,release=sustain?.31:.09;
            const double live=n.duration*sourceSecondsPerBeat;
            const double loopBegin=length*.32,loopEnd=length*.86,loopLength=loopEnd-loopBegin;
            const double fadeFrames=std::min(sample->sourceRate*.008,loopLength*.12);
            auto interpolate=[&](const float* src,double at)->float{
                const int i=static_cast<int>(at);
                const float f=static_cast<float>(at-i);
                return src[i]+(src[i+1]-src[i])*f;
            };
            equinox::forSampleSpans(beat,bpm,sr,samplesInBlock,n.beat,n.duration,release,
                [&](equinox::SampleSpan span){
                    const double startSeconds=(beat-span.startBeat)*sourceSecondsPerBeat;
                    double pos=(startSeconds+span.firstFrame/sr)*sr*playbackRate;
                    for(int i=span.firstFrame;i<span.endFrame;++i,pos+=playbackRate){
                        const double t=startSeconds+i/sr;
                        if(t<0||t>live+release)continue;
                        double cursor=pos;
                        bool crossfade=false;
                        double blend=0,other=0;
                        if(sustain && length>sample->sourceRate*.9 && loopLength>fadeFrames+2) {
                            if(cursor>=loopEnd)
                                cursor=loopBegin+fadeFrames+std::fmod(cursor-loopEnd,loopLength-fadeFrames);
                            else if(cursor>=loopEnd-fadeFrames){
                                crossfade=true;
                                blend=(cursor-(loopEnd-fadeFrames))/fadeFrames;
                                other=loopBegin+blend*fadeFrames;
                            }
                        }
                        if(cursor<0 || cursor>=length-1)continue;
                        float env=static_cast<float>(std::min(1.,t/attack));
                        if(t>live)env*=juce::jmax(0.f,static_cast<float>(1.-(t-live)/release));
                        const float amp=static_cast<float>(noteGain)*env;
                        float l=interpolate(srcL,cursor),r=interpolate(srcR,cursor);
                        if(crossfade && other<length-1){
                            l=static_cast<float>(l*(1.-blend)+interpolate(srcL,other)*blend);
                            r=static_cast<float>(r*(1.-blend)+interpolate(srcR,other)*blend);
                        }
                        left[i]+=amp*l;right[i]+=amp*r;
                    }
                });
        }
    }
    // Transparent limiter to prevent overloaded acoustic stacks.
    for(int i=0;i<samplesInBlock;i++){
        left[i]=std::tanh(left[i]*.96f);
        right[i]=std::tanh(right[i]*.96f);
    }
}

// One-time sample load happens on the plugin construction thread, never on the audio callback.
// Windows installer copies to %APPDATA%\EQUINOX Melody Forge\Samples.
void ForgeProcessor::loadFactoryBank(){
    // Factory bank sampled offline from GNU GPL-2.0 TimGM6mb.sf2.
    // This is not a professional recording of a live choir or performed chants.
    static constexpr const char* names[equinox::kTracks]={
       "SUB_808","LOW_PIANO","UPPER_KEYS","GUITAR","STRINGS","BELLS",
       "HOOK_LEAD","CHOIR","CHANTS","VOCAL_CHOPS","PADS","ARPEGGIATOR",
       "SYNTH_BASS","POLY_SYNTH","ORGANIC_TEXTURE","PLUCK"
    };
    static constexpr int roots[equinox::kTracks][5] = {
       {32,36,43,48,52},{39,43,50,57,61},{56,60,67,74,78},
       {48,52,59,66,70},{51,55,62,69,73},{68,72,79,86,90},
       {60,64,71,78,82},{48,52,59,66,70},{44,48,55,62,66},
       {60,64,71,78,82},{48,52,59,66,70},{60,64,71,78,82},
       {32,36,43,50,54},{51,55,62,69,73},{56,60,67,74,78},
       {63,67,74,81,85}
    };
    auto sourceDir=juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                     .getChildFile("EQUINOX Melody Forge").getChildFile("Samples");
    for(int t=0;t<equinox::kTracks;++t)
        for(int v=0;v<2;++v)
            for(int zone=0;zone<5;++zone)
                for(int dyn=0;dyn<2;++dyn){
                    auto filename=juce::String::formatted("%02d_%s_P%d_N%d_V%d.wav",t,names[t],v,roots[t][zone],dyn);
                    auto file=sourceDir.getChildFile(filename);
                    factoryBank[t][v][zone][dyn]=readSampleFile(file);
                }
}
