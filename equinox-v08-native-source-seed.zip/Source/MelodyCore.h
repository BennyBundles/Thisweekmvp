#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace equinox {
constexpr int kTracks = 16;
constexpr int kBars = 8;
constexpr int kBeatsPerBar = 4;
constexpr double kLoopBeats = 32.0;
constexpr int kPPQ = 960;

enum class Style { Trap, HipHop, Drill, Pain, Southern, JazzTrap };
enum class Scale { NaturalMinor, HarmonicMinor, Dorian, Phrygian, Major };
struct Note {
    int track = 0;
    int pitch = 60;
    double beat = 0;
    double duration = 0.5;
    int velocity = 90;
};
struct Settings {
    Style style = Style::Pain;
    Scale scale = Scale::NaturalMinor;
    int root = 9; // A
    int bpm = 136;
    uint32_t seed = 20261010;
    double density = 0.43;
    double swing = 0.12;
    double emotion = 0.7;
    double vocalAmount = 0.48;
    double atmosphere = 0.37;
    int substyle = -1; // -1 rotating producer profile; 0 intimate / 1 rhythmic / 2 lush
    std::array<int,kTracks> patches{}; // 0..3 per-layer synth voice; saved with preset
};
struct Pattern {
    Settings settings;
    std::array<std::string, kBars> chords{};
    std::vector<Note> notes;
};
extern const std::array<const char*, kTracks> trackNames;
extern const std::array<std::array<const char*,4>,kTracks> patchNames;
extern const std::array<const char*, 6> styleNames;
extern const std::array<const char*, 5> scaleNames;
extern const std::array<const char*, 12> rootNames;
int defaultBpm(Style style);
Pattern generate(const Settings& settings);
std::string describe(const Pattern& pattern);
std::vector<uint8_t> exportMidi(const Pattern& pattern, int onlyTrack = -1);
bool writeBinary(const std::string& path, const std::vector<uint8_t>& bytes);

// A deterministic synthesis engine shared by the VST3 instrument and offline audio renderer.
class AudioEngine {
public:
    void render(float* left, float* right, int numSamples, double firstBeat,
                double bpm, double sampleRate, const Pattern& pattern,
                const std::array<float,kTracks>& gains,
                const std::array<bool,kTracks>& mutes, float master = 0.75f) const;
    static std::vector<uint8_t> renderWav(const Pattern& pattern, int sampleRate = 44100,
                                         int onlyTrack = -1);
};
}
